#!/usr/bin/env python3
"""
Basic Example: Sentinel-1 Change Detection

This example demonstrates the basic usage of the Sentinel-1 change detection
package for detecting changes between two time periods.

Usage:
    python basic_example.py

Requirements:
    - Valid Copernicus Open Access Hub credentials
    - Internet connection for data download
    - Sufficient disk space for Sentinel-1 products

Author: Manus AI
Date: 2025
"""

import os
import sys
from pathlib import Path

# Add src directory to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from sentinel1_change_detection import Sentinel1ChangeDetection
from data_utils import DataUtils
from config_manager import ConfigManager


def main():
    """
    Main function demonstrating basic change detection workflow.
    """
    print("="*60)
    print("SENTINEL-1 SAR CHANGE DETECTION - BASIC EXAMPLE")
    print("="*60)
    
    # Step 1: Setup configuration
    print("\n1. Setting up configuration...")
    
    # Load configuration
    config_path = Path(__file__).parent.parent / 'config' / 'default_config.yaml'
    config_manager = ConfigManager(str(config_path))
    
    # Update credentials (you need to set these)
    print("   Please update your Copernicus credentials in the configuration file:")
    print(f"   {config_path}")
    print("   Username and password are required for data download.")
    
    # Step 2: Define Area of Interest (AOI)
    print("\n2. Defining Area of Interest...")
    
    # Example 1: Create AOI from bounding box (small area in Northern Italy)
    bounds = (11.0, 46.0, 11.5, 46.5)  # (min_lon, min_lat, max_lon, max_lat)
    aoi_geojson = DataUtils.create_aoi_from_bounds(bounds)
    
    print(f"   AOI bounds: {bounds}")
    print(f"   AOI type: {aoi_geojson['type']}")
    
    # Alternative: Create AOI from center point and buffer
    # center_lat, center_lon = 46.25, 11.25
    # buffer_km = 10
    # aoi_geojson = DataUtils.create_aoi_from_point(center_lat, center_lon, buffer_km)
    
    # Step 3: Define date range
    print("\n3. Defining date range...")
    
    # Define two time periods for change detection
    # Period 1: Before (reference)
    date_range_before = ('2023-01-01', '2023-03-31')
    
    # Period 2: After (target)
    date_range_after = ('2023-07-01', '2023-09-30')
    
    print(f"   Before period: {date_range_before[0]} to {date_range_before[1]}")
    print(f"   After period: {date_range_after[0]} to {date_range_after[1]}")
    
    # Validate date ranges
    if not DataUtils.validate_date_range(date_range_before):
        print("   ERROR: Invalid before date range")
        return
    
    if not DataUtils.validate_date_range(date_range_after):
        print("   ERROR: Invalid after date range")
        return
    
    # Step 4: Initialize processor
    print("\n4. Initializing Sentinel-1 processor...")
    
    processor = Sentinel1ChangeDetection(str(config_path))
    
    # Step 5: Process first time period (before)
    print("\n5. Processing first time period (before)...")
    
    try:
        results_before = processor.process_workflow(
            aoi_geojson=aoi_geojson,
            date_range=date_range_before,
            max_products=2
        )
        
        print(f"   Success: {results_before['success']}")
        print(f"   Products found: {results_before['products_found']}")
        print(f"   Products downloaded: {results_before['products_downloaded']}")
        
        if not results_before['success']:
            print(f"   Error: {results_before.get('error', 'Unknown error')}")
            print("   Please check your credentials and internet connection.")
            return
            
    except Exception as e:
        print(f"   Error processing before period: {e}")
        return
    
    # Step 6: Process second time period (after)
    print("\n6. Processing second time period (after)...")
    
    try:
        results_after = processor.process_workflow(
            aoi_geojson=aoi_geojson,
            date_range=date_range_after,
            max_products=2
        )
        
        print(f"   Success: {results_after['success']}")
        print(f"   Products found: {results_after['products_found']}")
        print(f"   Products downloaded: {results_after['products_downloaded']}")
        
        if not results_after['success']:
            print(f"   Error: {results_after.get('error', 'Unknown error')}")
            return
            
    except Exception as e:
        print(f"   Error processing after period: {e}")
        return
    
    # Step 7: Display results
    print("\n7. Results Summary:")
    print("   " + "="*50)
    
    print(f"   Before period:")
    print(f"     - Products found: {results_before['products_found']}")
    print(f"     - Products downloaded: {results_before['products_downloaded']}")
    print(f"     - Change maps: {len(results_before.get('change_maps', []))}")
    
    print(f"   After period:")
    print(f"     - Products found: {results_after['products_found']}")
    print(f"     - Products downloaded: {results_after['products_downloaded']}")
    print(f"     - Change maps: {len(results_after.get('change_maps', []))}")
    
    # List output files
    output_dir = Path(processor.output_dir)
    if output_dir.exists():
        output_files = list(output_dir.glob('*'))
        if output_files:
            print(f"\n   Output files created:")
            for file_path in sorted(output_files):
                print(f"     - {file_path.name}")
        else:
            print(f"\n   No output files found in {output_dir}")
    
    # Step 8: Next steps
    print("\n8. Next Steps:")
    print("   " + "="*50)
    print("   - Check the output directory for results")
    print("   - View generated visualizations (PNG files)")
    print("   - Examine change detection maps (GeoTIFF files)")
    print("   - Review processing logs for detailed information")
    print("   - Modify configuration for different processing options")
    
    print(f"\n   Output directory: {processor.output_dir}")
    print(f"   Log files: {processor.output_dir}/sentinel1_processing.log")
    
    print("\n" + "="*60)
    print("PROCESSING COMPLETED")
    print("="*60)


def demonstrate_configuration():
    """
    Demonstrate configuration management features.
    """
    print("\n" + "="*60)
    print("CONFIGURATION MANAGEMENT DEMO")
    print("="*60)
    
    # Initialize config manager
    config_manager = ConfigManager()
    
    # Display configuration summary
    print("\nCurrent Configuration:")
    print(config_manager.get_config_summary())
    
    # Demonstrate parameter access
    print("\nParameter Access Examples:")
    filter_type = config_manager.get_parameter('processing_parameters.speckle_filtering.filter_type')
    print(f"  Speckle filter type: {filter_type}")
    
    window_size = config_manager.get_parameter('processing_parameters.speckle_filtering.window_size')
    print(f"  Filter window size: {window_size}")
    
    # Demonstrate parameter modification
    print("\nModifying Parameters:")
    config_manager.set_parameter('processing_parameters.speckle_filtering.window_size', 7)
    new_window_size = config_manager.get_parameter('processing_parameters.speckle_filtering.window_size')
    print(f"  Updated window size: {new_window_size}")
    
    # Create template configuration
    template_path = Path(__file__).parent / 'template_config.yaml'
    if config_manager.create_template_config(str(template_path)):
        print(f"\nTemplate configuration created: {template_path}")


def demonstrate_aoi_creation():
    """
    Demonstrate different ways to create Area of Interest.
    """
    print("\n" + "="*60)
    print("AREA OF INTEREST CREATION DEMO")
    print("="*60)
    
    # Method 1: From bounding box
    print("\n1. AOI from bounding box:")
    bounds = (11.0, 46.0, 11.5, 46.5)
    aoi_bbox = DataUtils.create_aoi_from_bounds(bounds)
    print(f"   Bounds: {bounds}")
    print(f"   Features: {len(aoi_bbox['features'])}")
    
    # Method 2: From center point and buffer
    print("\n2. AOI from center point and buffer:")
    lat, lon = 46.25, 11.25
    buffer_km = 5
    aoi_point = DataUtils.create_aoi_from_point(lat, lon, buffer_km)
    print(f"   Center: ({lat}, {lon})")
    print(f"   Buffer: {buffer_km} km")
    print(f"   Features: {len(aoi_point['features'])}")
    
    # Validate AOI
    print("\n3. AOI validation:")
    is_valid_bbox = DataUtils.validate_geojson(aoi_bbox)
    is_valid_point = DataUtils.validate_geojson(aoi_point)
    print(f"   Bounding box AOI valid: {is_valid_bbox}")
    print(f"   Point buffer AOI valid: {is_valid_point}")


if __name__ == "__main__":
    # Run main example
    main()
    
    # Run additional demonstrations
    demonstrate_configuration()
    demonstrate_aoi_creation()
    
    print("\n" + "="*60)
    print("ALL EXAMPLES COMPLETED")
    print("="*60)

