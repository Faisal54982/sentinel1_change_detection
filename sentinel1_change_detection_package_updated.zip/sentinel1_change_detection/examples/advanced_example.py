#!/usr/bin/env python3
"""
Advanced Example: Sentinel-1 Change Detection

This example demonstrates advanced features of the Sentinel-1 change detection
package including custom preprocessing, multiple change detection methods,
and comprehensive visualization.

Usage:
    python advanced_example.py

Author: Manus AI
Date: 2025
"""

import os
import sys
import numpy as np
from pathlib import Path

# Add src directory to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from sentinel1_change_detection import Sentinel1ChangeDetection
from data_utils import DataUtils
from preprocessing import SARPreprocessor
from visualization import VisualizationTools
from config_manager import ConfigManager


def advanced_preprocessing_example():
    """
    Demonstrate advanced SAR preprocessing techniques.
    """
    print("\n" + "="*60)
    print("ADVANCED SAR PREPROCESSING EXAMPLE")
    print("="*60)
    
    # Initialize preprocessor
    preprocessor = SARPreprocessor()
    
    # Create synthetic SAR data for demonstration
    print("\n1. Creating synthetic SAR data...")
    np.random.seed(42)
    
    # Simulate SAR backscatter with speckle noise
    clean_signal = np.random.gamma(2, 2, (200, 200)).astype(np.float32)
    speckle_noise = np.random.gamma(1, 1, (200, 200))
    noisy_sar = clean_signal * speckle_noise
    
    print(f"   Original image shape: {noisy_sar.shape}")
    print(f"   Original image range: {np.min(noisy_sar):.2f} to {np.max(noisy_sar):.2f}")
    
    # Test different speckle filters
    print("\n2. Testing different speckle filters...")
    
    filters_to_test = ['lee', 'frost', 'kuan', 'gamma_map', 'adaptive']
    filtered_results = {}
    
    for filter_type in filters_to_test:
        print(f"   Applying {filter_type} filter...")
        
        if filter_type == 'lee':
            filtered = preprocessor.lee_filter(noisy_sar, window_size=5)
        elif filter_type == 'frost':
            filtered = preprocessor.frost_filter(noisy_sar, window_size=5)
        elif filter_type == 'kuan':
            filtered = preprocessor.kuan_filter(noisy_sar, window_size=5)
        elif filter_type == 'gamma_map':
            filtered = preprocessor.gamma_map_filter(noisy_sar, window_size=5)
        elif filter_type == 'adaptive':
            filtered = preprocessor.adaptive_filter(noisy_sar, window_size=5)
        
        filtered_results[filter_type] = filtered
        
        # Calculate noise reduction metrics
        noise_reduction = np.std(noisy_sar) - np.std(filtered)
        print(f"     Noise reduction: {noise_reduction:.3f}")
    
    # Test multilook processing
    print("\n3. Testing multilook processing...")
    multilooked = preprocessor.multilook_processing(noisy_sar, range_looks=2, azimuth_looks=2)
    print(f"   Multilooked shape: {multilooked.shape}")
    print(f"   Size reduction: {noisy_sar.size / multilooked.size:.1f}x")
    
    # Test radiometric calibration
    print("\n4. Testing radiometric calibration...")
    calibrated = preprocessor.radiometric_calibration(noisy_sar, calibration_type='sigma0')
    print(f"   Calibrated range: {np.min(calibrated):.2f} to {np.max(calibrated):.2f} dB")
    
    return filtered_results, multilooked, calibrated


def multiple_change_detection_methods():
    """
    Demonstrate different change detection methods.
    """
    print("\n" + "="*60)
    print("MULTIPLE CHANGE DETECTION METHODS")
    print("="*60)
    
    # Create synthetic before/after images
    print("\n1. Creating synthetic before/after images...")
    np.random.seed(42)
    
    # Before image
    before_image = np.random.gamma(2, 2, (150, 150)).astype(np.float32)
    
    # After image with some changes
    after_image = before_image.copy()
    
    # Add some changes in specific regions
    # Change 1: Increase in upper left
    after_image[20:50, 20:50] *= 1.5
    
    # Change 2: Decrease in center
    after_image[60:90, 60:90] *= 0.7
    
    # Change 3: New feature in lower right
    after_image[100:130, 100:130] += np.random.gamma(3, 1, (30, 30))
    
    print(f"   Before image range: {np.min(before_image):.2f} to {np.max(before_image):.2f}")
    print(f"   After image range: {np.min(after_image):.2f} to {np.max(after_image):.2f}")
    
    # Initialize processor for change detection methods
    processor = Sentinel1ChangeDetection()
    
    # Test different change detection methods
    print("\n2. Testing change detection methods...")
    
    methods = ['log_ratio', 'ratio', 'difference']
    change_results = {}
    
    for method in methods:
        print(f"   Testing {method} method...")
        
        if method == 'log_ratio':
            change_map = np.log(np.maximum(after_image, 1e-10)) - np.log(np.maximum(before_image, 1e-10))
        elif method == 'ratio':
            change_map = after_image / np.maximum(before_image, 1e-10)
        elif method == 'difference':
            change_map = np.abs(after_image - before_image)
        
        change_results[method] = change_map
        
        # Calculate change statistics
        change_pixels = np.sum(np.abs(change_map) > np.std(change_map))
        total_pixels = change_map.size
        change_percentage = (change_pixels / total_pixels) * 100
        
        print(f"     Change pixels: {change_pixels} ({change_percentage:.1f}%)")
        print(f"     Change range: {np.min(change_map):.3f} to {np.max(change_map):.3f}")
    
    return before_image, after_image, change_results


def comprehensive_visualization_example():
    """
    Demonstrate comprehensive visualization capabilities.
    """
    print("\n" + "="*60)
    print("COMPREHENSIVE VISUALIZATION EXAMPLE")
    print("="*60)
    
    # Initialize visualization tools
    viz = VisualizationTools()
    
    # Create sample data
    print("\n1. Creating sample data for visualization...")
    
    # Sample SAR images
    np.random.seed(42)
    sar_image1 = np.random.gamma(2, 2, (100, 100))
    sar_image2 = sar_image1 + np.random.normal(0, 0.3, (100, 100))
    change_map = sar_image2 - sar_image1
    binary_change = np.abs(change_map) > np.std(change_map)
    
    # Create sample statistics
    stats_dict = {
        'Original': {
            'band_1': {
                'mean': np.mean(sar_image1),
                'std': np.std(sar_image1),
                'min': np.min(sar_image1),
                'max': np.max(sar_image1)
            }
        },
        'Modified': {
            'band_1': {
                'mean': np.mean(sar_image2),
                'std': np.std(sar_image2),
                'min': np.min(sar_image2),
                'max': np.max(sar_image2)
            }
        }
    }
    
    print("   Sample data created successfully")
    
    # Test statistics comparison plot
    print("\n2. Creating statistics comparison plot...")
    try:
        fig = viz.plot_statistics_comparison(stats_dict)
        if fig:
            print("   Statistics comparison plot created")
            # In a real scenario, you would save this plot
            # fig.savefig('statistics_comparison.png')
        else:
            print("   Failed to create statistics comparison plot")
    except Exception as e:
        print(f"   Error creating statistics plot: {e}")
    
    # Test AOI visualization
    print("\n3. Creating AOI visualization...")
    try:
        # Create sample AOI
        bounds = (11.0, 46.0, 11.5, 46.5)
        aoi_geojson = DataUtils.create_aoi_from_bounds(bounds)
        
        fig = viz.plot_aoi_on_map(aoi_geojson)
        if fig:
            print("   AOI visualization created")
        else:
            print("   Failed to create AOI visualization")
    except Exception as e:
        print(f"   Error creating AOI plot: {e}")
    
    print("   Visualization examples completed")


def custom_configuration_example():
    """
    Demonstrate custom configuration management.
    """
    print("\n" + "="*60)
    print("CUSTOM CONFIGURATION EXAMPLE")
    print("="*60)
    
    # Initialize config manager
    config_manager = ConfigManager()
    
    print("\n1. Creating custom configuration...")
    
    # Modify configuration for specific use case
    config_manager.set_parameter('search_parameters.product_type', 'SLC')
    config_manager.set_parameter('search_parameters.max_products', 3)
    config_manager.set_parameter('processing_parameters.speckle_filtering.filter_type', 'adaptive')
    config_manager.set_parameter('processing_parameters.speckle_filtering.window_size', 7)
    config_manager.set_parameter('change_detection.method', 'log_ratio')
    config_manager.set_parameter('change_detection.threshold_method', 'percentile')
    config_manager.set_parameter('change_detection.threshold_percentile', 90)
    
    print("   Custom parameters set:")
    print(f"     Product type: {config_manager.get_parameter('search_parameters.product_type')}")
    print(f"     Max products: {config_manager.get_parameter('search_parameters.max_products')}")
    print(f"     Filter type: {config_manager.get_parameter('processing_parameters.speckle_filtering.filter_type')}")
    print(f"     Window size: {config_manager.get_parameter('processing_parameters.speckle_filtering.window_size')}")
    print(f"     Change detection method: {config_manager.get_parameter('change_detection.method')}")
    print(f"     Threshold method: {config_manager.get_parameter('change_detection.threshold_method')}")
    
    # Save custom configuration
    print("\n2. Saving custom configuration...")
    custom_config_path = Path(__file__).parent / 'custom_config.yaml'
    
    if config_manager.save_config(str(custom_config_path)):
        print(f"   Custom configuration saved: {custom_config_path}")
    else:
        print("   Failed to save custom configuration")
    
    # Validate configuration
    print("\n3. Validating configuration...")
    is_valid = config_manager.validate_config()
    print(f"   Configuration valid: {is_valid}")
    
    # Display configuration summary
    print("\n4. Configuration summary:")
    summary = config_manager.get_config_summary()
    print(summary)


def batch_processing_example():
    """
    Demonstrate batch processing for multiple AOIs or time periods.
    """
    print("\n" + "="*60)
    print("BATCH PROCESSING EXAMPLE")
    print("="*60)
    
    print("\n1. Setting up batch processing scenario...")
    
    # Define multiple AOIs
    aois = [
        {
            'name': 'Area_1',
            'bounds': (11.0, 46.0, 11.2, 46.2),
            'description': 'Northern Italy - Area 1'
        },
        {
            'name': 'Area_2', 
            'bounds': (11.3, 46.3, 11.5, 46.5),
            'description': 'Northern Italy - Area 2'
        }
    ]
    
    # Define multiple time periods
    time_periods = [
        {
            'name': 'Winter_2023',
            'date_range': ('2023-01-01', '2023-03-31'),
            'description': 'Winter 2023'
        },
        {
            'name': 'Summer_2023',
            'date_range': ('2023-06-01', '2023-08-31'),
            'description': 'Summer 2023'
        }
    ]
    
    print(f"   Number of AOIs: {len(aois)}")
    print(f"   Number of time periods: {len(time_periods)}")
    
    # Simulate batch processing workflow
    print("\n2. Simulating batch processing workflow...")
    
    batch_results = []
    
    for aoi in aois:
        for period in time_periods:
            print(f"   Processing {aoi['name']} - {period['name']}...")
            
            # Create AOI GeoJSON
            aoi_geojson = DataUtils.create_aoi_from_bounds(aoi['bounds'])
            
            # Validate date range
            if DataUtils.validate_date_range(period['date_range']):
                # In a real scenario, you would run the actual processing here
                result = {
                    'aoi_name': aoi['name'],
                    'period_name': period['name'],
                    'aoi_bounds': aoi['bounds'],
                    'date_range': period['date_range'],
                    'status': 'simulated',
                    'products_found': np.random.randint(1, 5),  # Simulated
                    'processing_time': np.random.uniform(10, 60)  # Simulated
                }
                batch_results.append(result)
                print(f"     Status: {result['status']}")
                print(f"     Products found: {result['products_found']}")
            else:
                print(f"     Error: Invalid date range {period['date_range']}")
    
    # Display batch results summary
    print("\n3. Batch processing results summary:")
    print("   " + "="*50)
    
    for result in batch_results:
        print(f"   {result['aoi_name']} - {result['period_name']}:")
        print(f"     Products: {result['products_found']}")
        print(f"     Time: {result['processing_time']:.1f}s")
    
    total_products = sum(r['products_found'] for r in batch_results)
    total_time = sum(r['processing_time'] for r in batch_results)
    
    print(f"\n   Total products processed: {total_products}")
    print(f"   Total processing time: {total_time:.1f}s")
    print(f"   Average products per job: {total_products/len(batch_results):.1f}")


def main():
    """
    Main function running all advanced examples.
    """
    print("="*60)
    print("SENTINEL-1 SAR CHANGE DETECTION - ADVANCED EXAMPLES")
    print("="*60)
    
    try:
        # Run advanced preprocessing example
        filtered_results, multilooked, calibrated = advanced_preprocessing_example()
        
        # Run multiple change detection methods
        before_img, after_img, change_results = multiple_change_detection_methods()
        
        # Run comprehensive visualization example
        comprehensive_visualization_example()
        
        # Run custom configuration example
        custom_configuration_example()
        
        # Run batch processing example
        batch_processing_example()
        
        print("\n" + "="*60)
        print("ALL ADVANCED EXAMPLES COMPLETED SUCCESSFULLY")
        print("="*60)
        
        print("\nKey takeaways from advanced examples:")
        print("- Multiple speckle filtering methods available")
        print("- Different change detection algorithms for various scenarios")
        print("- Comprehensive visualization and reporting capabilities")
        print("- Flexible configuration management")
        print("- Support for batch processing workflows")
        
    except Exception as e:
        print(f"\nError running advanced examples: {e}")
        print("Please check your environment and dependencies.")


if __name__ == "__main__":
    main()

