# Migration Guide: Copernicus Open Access Hub to Copernicus Data Space Ecosystem

This guide helps users migrate from the deprecated Copernicus Open Access Hub to the new Copernicus Data Space Ecosystem (CDSE).

## Important Notice

⚠️ **The Copernicus Open Access Hub (https://scihub.copernicus.eu/) was permanently discontinued in October 2023.**

All Sentinel data access has been migrated to the **Copernicus Data Space Ecosystem (CDSE)**.

## What Changed

### 1. New Registration Portal
- **Old**: https://scihub.copernicus.eu/
- **New**: https://dataspace.copernicus.eu/

### 2. New API Endpoints
- **Old**: https://scihub.copernicus.eu/dhus
- **New**: https://catalogue.dataspace.copernicus.eu/odata/v1

### 3. Enhanced Features
- **Improved Performance**: Faster data discovery and download
- **Better API**: More robust and feature-rich APIs
- **Extended Services**: Additional processing and analysis capabilities
- **Modern Infrastructure**: Cloud-native architecture

## Migration Steps

### Step 1: Create New CDSE Account

1. Visit https://dataspace.copernicus.eu/
2. Click "Register" to create a new account
3. Complete email verification
4. Note your new credentials

**Important**: Your old Copernicus Open Access Hub credentials will NOT work with CDSE.

### Step 2: Update Configuration

Update your configuration file with new credentials:

```yaml
# OLD Configuration (deprecated)
credentials:
  username: "old_scihub_username"
  password: "old_scihub_password"

# NEW Configuration (CDSE)
credentials:
  username: "your_cdse_username"
  password: "your_cdse_password"
```

### Step 3: Update Code (if using custom scripts)

If you're using custom scripts with sentinelsat, update the API endpoint:

```python
# OLD Code (deprecated)
from sentinelsat import SentinelAPI
api = SentinelAPI('username', 'password', 'https://scihub.copernicus.eu/dhus')

# NEW Code (CDSE compatible)
from sentinelsat import SentinelAPI
api = SentinelAPI('username', 'password', 'https://catalogue.dataspace.copernicus.eu/odata/v1')
```

### Step 4: Update Dependencies

Ensure you're using a compatible version of sentinelsat:

```bash
pip install --upgrade sentinelsat>=1.2.0
```

## Key Differences

### Authentication
- **Old**: Basic HTTP authentication
- **New**: OAuth2 authentication (handled automatically by sentinelsat)

### Data Access
- **Old**: Direct download from single hub
- **New**: Distributed cloud infrastructure with multiple access points

### Performance
- **Old**: Limited concurrent downloads
- **New**: Improved download speeds and reliability

### API Features
- **Old**: Basic search and download
- **New**: Enhanced search, filtering, and processing capabilities

## Troubleshooting Migration Issues

### Issue: "Connection refused" or "404 Not Found"
**Cause**: Still using old API endpoints
**Solution**: Update API endpoint to CDSE URL

### Issue: "Authentication failed"
**Cause**: Using old credentials or incorrect endpoint
**Solution**: 
1. Create new CDSE account
2. Update configuration with new credentials
3. Verify API endpoint is correct

### Issue: "No products found"
**Cause**: Different search parameter handling in CDSE
**Solution**: 
1. Check date format (should be 'YYYY-MM-DD')
2. Verify AOI coordinates
3. Review search parameters

### Issue: "Download fails"
**Cause**: Different download mechanisms in CDSE
**Solution**:
1. Ensure stable internet connection
2. Update sentinelsat to latest version
3. Check available disk space

## Benefits of CDSE

### 1. Improved Reliability
- Better uptime and availability
- More robust error handling
- Automatic retry mechanisms

### 2. Enhanced Performance
- Faster search and discovery
- Improved download speeds
- Better concurrent access

### 3. Extended Capabilities
- Additional data processing services
- Enhanced visualization tools
- Integration with cloud platforms

### 4. Future-Proof
- Regular updates and improvements
- Long-term support guaranteed
- Integration with new Sentinel missions

## Compatibility Notes

### SentinelSat Library
- **Minimum Version**: 1.2.0 (for CDSE support)
- **Recommended**: Latest version
- **Breaking Changes**: API endpoint only

### Data Products
- **Same Data**: All Sentinel-1 products available
- **Same Formats**: No changes to data formats
- **Same Metadata**: Product metadata unchanged

### Search Parameters
- **Same Syntax**: Search parameters unchanged
- **Same Results**: Same data products returned
- **Improved Filtering**: Additional filter options available

## Support and Resources

### Official Documentation
- **CDSE Documentation**: https://documentation.dataspace.copernicus.eu/
- **API Reference**: https://dataspace.copernicus.eu/analyse/apis
- **User Forum**: https://forum.dataspace.copernicus.eu/

### Community Resources
- **SentinelSat GitHub**: https://github.com/sentinelsat/sentinelsat
- **Stack Overflow**: Tag questions with 'sentinelsat' and 'copernicus'
- **ESA Forum**: https://forum.step.esa.int/

### Getting Help
1. **Check Documentation**: Review CDSE and sentinelsat documentation
2. **Search Forums**: Look for similar migration issues
3. **Create Support Ticket**: Contact CDSE support for account issues
4. **Community Support**: Ask questions in relevant forums

## Migration Checklist

- [ ] Create new CDSE account at https://dataspace.copernicus.eu/
- [ ] Verify email and activate account
- [ ] Update configuration files with new credentials
- [ ] Update API endpoints in custom scripts
- [ ] Upgrade sentinelsat to version 1.2.0 or higher
- [ ] Test connection with new credentials
- [ ] Verify data search and download functionality
- [ ] Update documentation and team knowledge
- [ ] Archive old credentials securely

## Conclusion

The migration to Copernicus Data Space Ecosystem represents a significant improvement in Sentinel data access. While it requires updating credentials and endpoints, the enhanced performance and capabilities make it a worthwhile upgrade.

The Sentinel-1 SAR Change Detection package has been updated to work seamlessly with CDSE, ensuring continued access to Sentinel-1 data for change detection workflows.

For additional support during migration, please refer to the official CDSE documentation or contact the support team.

---

**Last Updated**: January 2025  
**Package Version**: 1.0.0  
**CDSE Compatibility**: Full

