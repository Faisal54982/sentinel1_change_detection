# Sentinel-1 SAR Change Detection User Guide

This comprehensive user guide provides detailed instructions for using the Sentinel-1 SAR Change Detection package, from basic setup to advanced analysis workflows.

## Table of Contents

1. [Getting Started](#getting-started)
2. [Configuration Management](#configuration-management)
3. [Data Acquisition](#data-acquisition)
4. [SAR Preprocessing](#sar-preprocessing)
5. [Change Detection Analysis](#change-detection-analysis)
6. [Visualization and Reporting](#visualization-and-reporting)
7. [Advanced Workflows](#advanced-workflows)
8. [Best Practices](#best-practices)
9. [Troubleshooting](#troubleshooting)

## Getting Started

### System Requirements

- **Operating System**: Linux, macOS, or Windows
- **Python**: Version 3.8 or higher
- **Memory**: Minimum 8GB RAM (16GB recommended)
- **Storage**: At least 10GB free space for data and processing
- **Internet**: Stable connection for data download

### Installation

1. **Clone the Repository**
```bash
git clone https://github.com/manus-ai/sentinel1-change-detection.git
cd sentinel1-change-detection
```

2. **Install Dependencies**
```bash
pip install -r requirements.txt
```

3. **Verify Installation**
```bash
python -c "from src.sentinel1_change_detection import Sentinel1ChangeDetection; print('Installation successful!')"
```

### Copernicus Data Space Ecosystem Account Setup

1. **Create Account**: Register at [Copernicus Data Space Ecosystem](https://dataspace.copernicus.eu/)
2. **Verify Email**: Complete email verification
3. **Note Credentials**: Save your username and password for configuration

## Configuration Management

### Creating Configuration Files

The package uses YAML configuration files for parameter management. Start by creating a template:

```python
from src.config_manager import ConfigManager

config_manager = ConfigManager()
config_manager.create_template_config('my_config.yaml')
```

### Configuration Structure

#### Basic Configuration
```yaml
# Copernicus Data Space Ecosystem credentials
# Register at: https://dataspace.copernicus.eu/
credentials:
  username: "your_username"
  password: "your_password"

# Search parameters
search_parameters:
  product_type: "GRD"
  sensor_mode: "IW"
  polarization: "VV VH"
  orbit_direction: "DESCENDING"
  max_products: 5

# Processing settings
processing_parameters:
  radiometric_calibration:
    enabled: true
    calibration_type: "sigma0"
  
  speckle_filtering:
    enabled: true
    filter_type: "lee"
    window_size: 5

# Change detection
change_detection:
  method: "log_ratio"
  threshold_method: "otsu"
  post_processing:
    min_area: 100

# Directory paths
paths:
  data_dir: "./data"
  output_dir: "./output"
  temp_dir: "./temp"
```

#### Advanced Configuration Options

**Search Parameters**
- `product_type`: "GRD" (Ground Range Detected) or "SLC" (Single Look Complex)
- `sensor_mode`: "IW" (Interferometric Wide), "EW" (Extra Wide), "SM" (Strip Map)
- `polarization`: Available polarizations (VV, VH, HH, HV)
- `orbit_direction`: "ASCENDING" or "DESCENDING"
- `relative_orbit`: Specific orbit number (optional)

**Processing Parameters**
- `calibration_type`: "sigma0" (recommended), "beta0", or "gamma0"
- `filter_type`: "lee", "frost", "kuan", "gamma_map", or "adaptive"
- `window_size`: Filter window size (odd numbers: 3, 5, 7, 9)

**Change Detection Methods**
- `log_ratio`: Optimal for SAR data (recommended)
- `ratio`: Simple intensity ratio
- `difference`: Absolute difference

### Configuration Validation

```python
config_manager = ConfigManager('my_config.yaml')
is_valid = config_manager.validate_config()
if is_valid:
    print("Configuration is valid")
else:
    print("Configuration has errors")
```

## Data Acquisition

### Defining Area of Interest (AOI)

#### Method 1: Bounding Box
```python
from src.data_utils import DataUtils

# Define bounds (min_lon, min_lat, max_lon, max_lat)
bounds = (11.0, 46.0, 11.5, 46.5)
aoi_geojson = DataUtils.create_aoi_from_bounds(bounds)
```

#### Method 2: Center Point and Buffer
```python
# Define center point and buffer distance
lat, lon = 46.25, 11.25
buffer_km = 10
aoi_geojson = DataUtils.create_aoi_from_point(lat, lon, buffer_km)
```

#### Method 3: Custom GeoJSON
```python
# Load from file
aoi_geojson = "path/to/your/aoi.geojson"

# Or define manually
aoi_geojson = {
    "type": "FeatureCollection",
    "features": [{
        "type": "Feature",
        "properties": {},
        "geometry": {
            "type": "Polygon",
            "coordinates": [[[lon1, lat1], [lon2, lat2], ...]]
        }
    }]
}
```

### Date Range Selection

```python
# Define time periods for change detection
date_range_before = ('2023-01-01', '2023-03-31')  # Reference period
date_range_after = ('2023-07-01', '2023-09-30')   # Target period

# Validate date ranges
if DataUtils.validate_date_range(date_range_before):
    print("Date range is valid")
```

### Product Search and Download

```python
from src.sentinel1_change_detection import Sentinel1ChangeDetection

# Initialize processor
processor = Sentinel1ChangeDetection('my_config.yaml')

# Connect to API
if processor.connect_to_api():
    print("Connected to Copernicus Data Space Ecosystem")
    
    # Search for products
    products_df = processor.search_products(aoi_geojson, date_range_before)
    print(f"Found {len(products_df)} products")
    
    # Download products
    downloaded_files = processor.download_products(products_df, max_products=2)
    print(f"Downloaded {len(downloaded_files)} files")
```

## SAR Preprocessing

### Understanding SAR Data

Sentinel-1 SAR data requires specialized preprocessing due to:
- **Speckle Noise**: Inherent multiplicative noise in SAR images
- **Radiometric Effects**: Need for calibration to physical units
- **Geometric Distortions**: Terrain-induced geometric effects

### Radiometric Calibration

Converts digital numbers (DN) to backscatter coefficients:

```python
from src.preprocessing import SARPreprocessor

preprocessor = SARPreprocessor()

# Apply radiometric calibration
calibrated_image = preprocessor.radiometric_calibration(
    input_data=raw_sar_data,
    calibration_type='sigma0'  # sigma0, beta0, or gamma0
)
```

**Calibration Types:**
- **Sigma0 (σ⁰)**: Radar cross-section per unit area (recommended)
- **Beta0 (β⁰)**: Radar brightness per unit area in slant range
- **Gamma0 (γ⁰)**: Radar brightness per unit area in ground range

### Speckle Filtering

Reduces speckle noise while preserving image features:

#### Lee Filter
```python
lee_filtered = preprocessor.lee_filter(
    image=calibrated_image,
    window_size=5,
    cu=0.25  # Noise coefficient
)
```

#### Frost Filter
```python
frost_filtered = preprocessor.frost_filter(
    image=calibrated_image,
    window_size=5,
    damping_factor=1.0
)
```

#### Adaptive Filter
```python
# Automatically selects best filter based on image characteristics
adaptive_filtered = preprocessor.adaptive_filter(
    image=calibrated_image,
    window_size=5
)
```

### Multilook Processing

Reduces speckle through spatial averaging:

```python
multilooked = preprocessor.multilook_processing(
    image=filtered_image,
    range_looks=2,
    azimuth_looks=2
)
```

### Complete Preprocessing Pipeline

```python
# Process SAR image with full pipeline
success = preprocessor.process_sar_image(
    input_path='raw_sar_image.tif',
    output_path='processed_sar_image.tif',
    calibration_type='sigma0',
    speckle_filter='adaptive',
    window_size=5,
    multilook=False,
    target_resolution=10.0
)
```

## Change Detection Analysis

### Change Detection Methods

#### Log-Ratio Method (Recommended for SAR)
```python
import numpy as np

# Calculate log-ratio change
change_map = np.log(np.maximum(after_image, 1e-10)) - np.log(np.maximum(before_image, 1e-10))
```

**Advantages:**
- Optimal for SAR data
- Symmetric for increases/decreases
- Reduces multiplicative noise effects

#### Ratio Method
```python
# Calculate ratio change
change_map = after_image / np.maximum(before_image, 1e-10)
```

#### Difference Method
```python
# Calculate absolute difference
change_map = np.abs(after_image - before_image)
```

### Threshold Selection

#### Automatic Thresholding (Otsu's Method)
```python
from skimage import filters

threshold = filters.threshold_otsu(np.abs(change_map))
binary_change = np.abs(change_map) > threshold
```

#### Statistical Thresholding
```python
# Mean-based threshold
threshold = np.nanmean(np.abs(change_map))

# Percentile-based threshold
threshold = np.nanpercentile(np.abs(change_map), 95)
```

### Complete Change Detection Workflow

```python
# Perform change detection
success = processor.change_detection(
    image1_path='before_image.tif',
    image2_path='after_image.tif',
    output_path='change_map.tif',
    method='log_ratio'
)

if success:
    print("Change detection completed successfully")
```

### Post-Processing

#### Remove Small Areas
```python
from skimage import morphology

# Remove small change areas
min_area = 100  # pixels
binary_change_filtered = morphology.remove_small_objects(
    binary_change, min_size=min_area
)
```

#### Morphological Operations
```python
from skimage.morphology import opening, closing, disk

# Apply morphological opening
kernel = disk(2)
cleaned_change = opening(binary_change, kernel)
```

## Visualization and Reporting

### Basic Visualizations

#### SAR Image Display
```python
from src.visualization import VisualizationTools

viz = VisualizationTools()

# Plot SAR image
fig = viz.plot_sar_image(
    image_path='sar_image.tif',
    title='Sentinel-1 SAR Image',
    percentile_stretch=(2, 98),
    colormap='gray'
)
```

#### Change Detection Results
```python
# Plot change detection results
fig = viz.plot_change_detection_results(
    change_map_path='change_map.tif',
    title='Change Detection Results'
)
```

#### Before/After Comparison
```python
# Compare before and after images
fig = viz.plot_before_after_comparison(
    image1_path='before.tif',
    image2_path='after.tif',
    change_map_path='change_map.tif',
    titles=['Before', 'After', 'Changes']
)
```

### Advanced Visualizations

#### Processing Workflow
```python
# Show processing steps
fig = viz.plot_processing_workflow(
    original_path='original.tif',
    calibrated_path='calibrated.tif',
    filtered_path='filtered.tif'
)
```

#### Statistical Analysis
```python
# Compare image statistics
stats_dict = {
    'Before': processor.calculate_image_statistics('before.tif'),
    'After': processor.calculate_image_statistics('after.tif')
}

fig = viz.plot_statistics_comparison(stats_dict)
```

### Report Generation

```python
# Create comprehensive HTML report
report_path = viz.create_processing_report(
    results=processing_results,
    output_dir='./reports'
)
print(f"Report created: {report_path}")
```

## Advanced Workflows

### Batch Processing

Process multiple AOIs or time periods:

```python
# Define multiple areas and time periods
aois = [
    {'name': 'Area1', 'bounds': (11.0, 46.0, 11.2, 46.2)},
    {'name': 'Area2', 'bounds': (11.3, 46.3, 11.5, 46.5)}
]

time_periods = [
    {'name': 'Winter', 'dates': ('2023-01-01', '2023-03-31')},
    {'name': 'Summer', 'dates': ('2023-06-01', '2023-08-31')}
]

# Process all combinations
for aoi in aois:
    for period in time_periods:
        aoi_geojson = DataUtils.create_aoi_from_bounds(aoi['bounds'])
        results = processor.process_workflow(
            aoi_geojson=aoi_geojson,
            date_range=period['dates'],
            max_products=2
        )
        print(f"Processed {aoi['name']} - {period['name']}: {results['success']}")
```

### Custom Preprocessing Workflows

```python
# Create custom preprocessing pipeline
def custom_preprocessing_pipeline(input_path, output_path):
    preprocessor = SARPreprocessor()
    
    # Step 1: Load image
    with rasterio.open(input_path) as src:
        image = src.read(1).astype(np.float32)
        profile = src.profile.copy()
    
    # Step 2: Radiometric calibration
    calibrated = preprocessor.radiometric_calibration(image, 'sigma0')
    
    # Step 3: Advanced speckle filtering
    lee_filtered = preprocessor.lee_filter(calibrated, window_size=5)
    frost_filtered = preprocessor.frost_filter(calibrated, window_size=5)
    
    # Step 4: Combine filters (weighted average)
    combined = 0.7 * lee_filtered + 0.3 * frost_filtered
    
    # Step 5: Save result
    profile.update(dtype=rasterio.float32)
    with rasterio.open(output_path, 'w', **profile) as dst:
        dst.write(combined, 1)
    
    return True

# Apply custom pipeline
success = custom_preprocessing_pipeline('input.tif', 'output.tif')
```

### Multi-Temporal Analysis

Analyze changes across multiple time periods:

```python
# Define multiple time periods
time_series = [
    ('2023-01-01', '2023-02-28'),
    ('2023-03-01', '2023-04-30'),
    ('2023-05-01', '2023-06-30'),
    ('2023-07-01', '2023-08-31')
]

change_maps = []
for i in range(len(time_series) - 1):
    # Process each consecutive pair
    results = processor.process_workflow(
        aoi_geojson=aoi_geojson,
        date_range=time_series[i],
        max_products=1
    )
    
    if results['success'] and results['change_maps']:
        change_maps.append(results['change_maps'][0])

# Analyze temporal patterns
print(f"Created {len(change_maps)} change maps for temporal analysis")
```

## Best Practices

### Data Selection Guidelines

1. **Temporal Baseline**
   - Short-term changes: Days to weeks
   - Seasonal changes: Months
   - Long-term changes: Years

2. **Spatial Considerations**
   - AOI size: Balance between detail and processing time
   - Resolution: 10m for GRD products, higher for SLC

3. **Orbit Selection**
   - Use same orbit direction for consistency
   - Consider local time of acquisition

### Preprocessing Recommendations

1. **Always Apply Calibration**
   - Use sigma0 for most applications
   - Consistent calibration across time series

2. **Speckle Filter Selection**
   - Lee filter: General purpose
   - Adaptive filter: Unknown conditions
   - Frost filter: Preserve edges

3. **Window Size Selection**
   - Smaller windows (3x3, 5x5): Preserve detail
   - Larger windows (7x7, 9x9): Better noise reduction

### Change Detection Best Practices

1. **Method Selection**
   - Log-ratio: Recommended for SAR
   - Difference: For calibrated data only
   - Ratio: Simple but less robust

2. **Threshold Selection**
   - Otsu's method: Automatic, generally reliable
   - Visual inspection: Always validate results
   - Statistical methods: For specific applications

3. **Post-Processing**
   - Remove small areas: Reduce false positives
   - Morphological operations: Clean up results
   - Validation: Ground truth when available

### Performance Optimization

1. **Memory Management**
   - Process large areas in chunks
   - Use appropriate data types
   - Clean temporary files

2. **Processing Speed**
   - Enable parallel processing
   - Use SSD storage for temporary files
   - Optimize window sizes

3. **Quality Control**
   - Check intermediate results
   - Validate against known changes
   - Document processing parameters

## Troubleshooting

### Common Issues and Solutions

#### Authentication Problems
**Issue**: Cannot connect to Copernicus Data Space Ecosystem
```
Error: Failed to connect to API
```
**Solutions**:
1. Verify username and password in configuration
2. Check internet connection
3. Ensure Copernicus Data Space Ecosystem account is active
4. Try different API endpoint if available

#### Data Download Issues
**Issue**: No products found or download fails
```
Error: No products found for specified criteria
```
**Solutions**:
1. Check date range validity
2. Verify AOI coordinates (longitude/latitude order)
3. Adjust search parameters (orbit direction, product type)
4. Check data availability for your region and time period

#### Memory Errors
**Issue**: Out of memory during processing
```
MemoryError: Unable to allocate array
```
**Solutions**:
1. Reduce AOI size
2. Process images in chunks
3. Use lower resolution data
4. Increase system memory or use cloud computing

#### Processing Errors
**Issue**: Preprocessing fails
```
Error: Processing failed at speckle filtering step
```
**Solutions**:
1. Check input data format and validity
2. Verify file paths and permissions
3. Try different filter parameters
4. Check for corrupted data files

#### Visualization Issues
**Issue**: Plots not displaying correctly
```
Error: Cannot create visualization
```
**Solutions**:
1. Check matplotlib backend settings
2. Verify input data ranges
3. Update visualization libraries
4. Try different plot parameters

### Performance Troubleshooting

#### Slow Processing
**Symptoms**: Processing takes very long time
**Solutions**:
1. Enable parallel processing in configuration
2. Use faster storage (SSD)
3. Optimize filter window sizes
4. Consider cloud computing for large areas

#### High Memory Usage
**Symptoms**: System becomes unresponsive
**Solutions**:
1. Monitor memory usage during processing
2. Reduce chunk sizes in configuration
3. Close other applications
4. Use memory-efficient data types

### Getting Help

1. **Check Documentation**: Review this user guide and API documentation
2. **Search Issues**: Look for similar problems in GitHub issues
3. **Create Issue**: Report bugs with detailed information
4. **Community Support**: Join discussions for help and tips
5. **Professional Support**: Contact support@manus.ai for commercial support

---

This user guide provides comprehensive instructions for using the Sentinel-1 SAR Change Detection package. For additional information, please refer to the API documentation and example scripts included with the package.

