#!/usr/bin/env python3
"""
Setup script for Sentinel-1 SAR Change Detection package.

This script provides installation and setup functionality for the
Sentinel-1 change detection package.

Usage:
    python setup.py install
    python setup.py develop
    python setup.py test

Author: Manus AI
Date: 2025
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README file
readme_file = Path(__file__).parent / "README.md"
if readme_file.exists():
    with open(readme_file, "r", encoding="utf-8") as f:
        long_description = f.read()
else:
    long_description = "Sentinel-1 SAR Change Detection Package"

# Read requirements
requirements_file = Path(__file__).parent / "requirements.txt"
if requirements_file.exists():
    with open(requirements_file, "r", encoding="utf-8") as f:
        requirements = [line.strip() for line in f if line.strip() and not line.startswith("#")]
else:
    requirements = [
        "numpy>=1.21.0",
        "scipy>=1.7.0",
        "pandas>=1.3.0",
        "rasterio>=1.3.0",
        "geopandas>=0.11.0",
        "shapely>=1.8.0",
        "pyproj>=3.3.0",
        "fiona>=1.8.0",
        "sentinelsat>=1.2.0",
        "requests>=2.28.0",
        "scikit-image>=0.19.0",
        "opencv-python>=4.6.0",
        "matplotlib>=3.5.0",
        "pillow>=9.0.0",
        "tqdm>=4.64.0",
        "pyyaml>=6.0",
        "loguru>=0.6.0"
    ]

setup(
    name="sentinel1-change-detection",
    version="1.0.0",
    author="Manus AI",
    author_email="support@manus.ai",
    description="Comprehensive Python package for Sentinel-1 SAR change detection",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/manus-ai/sentinel1-change-detection",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: GIS",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-cov>=2.0",
            "black>=21.0",
            "flake8>=3.8",
            "mypy>=0.800",
        ],
        "docs": [
            "sphinx>=4.0",
            "sphinx-rtd-theme>=1.0",
            "myst-parser>=0.15",
        ],
        "jupyter": [
            "jupyter>=1.0",
            "ipykernel>=6.0",
            "ipywidgets>=7.0",
        ]
    },
    entry_points={
        "console_scripts": [
            "sentinel1-change-detection=sentinel1_change_detection:main",
        ],
    },
    include_package_data=True,
    package_data={
        "": ["*.yaml", "*.yml", "*.json", "*.txt"],
    },
    zip_safe=False,
    keywords="sentinel-1 sar change-detection remote-sensing geospatial",
    project_urls={
        "Bug Reports": "https://github.com/manus-ai/sentinel1-change-detection/issues",
        "Source": "https://github.com/manus-ai/sentinel1-change-detection",
        "Documentation": "https://sentinel1-change-detection.readthedocs.io/",
    },
)

