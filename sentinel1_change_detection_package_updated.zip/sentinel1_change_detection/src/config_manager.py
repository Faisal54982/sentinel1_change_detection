#!/usr/bin/env python3
"""
Configuration Manager Module

This module provides configuration management for Sentinel-1 change detection
processing, including parameter validation and default settings.

Author: Manus AI
Date: 2025
"""

import os
import yaml
import json
from pathlib import Path
from typing import Dict, Any, Optional, Union
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

from loguru import logger


class ConfigManager:
    """
    Configuration manager for Sentinel-1 processing parameters.
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize configuration manager.
        
        Args:
            config_path: Path to configuration file
        """
        self.logger = logger
        self.config_path = config_path
        self.config = self._load_default_config()
        
        if config_path:
            self.load_config(config_path)
    
    def _load_default_config(self) -> Dict[str, Any]:
        """
        Load default configuration parameters.
        
        Returns:
            Default configuration dictionary
        """
        default_config = {
            'metadata': {
                'version': '1.0.0',
                'created': datetime.now().isoformat(),
                'description': 'Sentinel-1 SAR Change Detection Configuration'
            },
            
            'credentials': {
                'username': '',
                'password': '',
                'api_url': 'https://apihub.copernicus.eu/apihub'
            },
            
            'search_parameters': {
                'product_type': 'GRD',  # GRD, SLC
                'sensor_mode': 'IW',    # IW, EW, SM
                'polarization': 'VV VH',  # VV, VH, HH, HV
                'orbit_direction': 'DESCENDING',  # ASCENDING, DESCENDING
                'relative_orbit': None,
                'max_cloud_cover': 100,
                'max_products': 10
            },
            
            'processing_parameters': {
                'radiometric_calibration': {
                    'enabled': True,
                    'calibration_type': 'sigma0',  # sigma0, beta0, gamma0
                    'noise_equivalent_sigma0': -22.0
                },
                
                'speckle_filtering': {
                    'enabled': True,
                    'filter_type': 'lee',  # lee, frost, kuan, gamma_map, adaptive
                    'window_size': 5,
                    'damping_factor': 1.0,  # For Frost filter
                    'noise_coefficient': 0.25  # For Lee/Kuan filters
                },
                
                'multilook_processing': {
                    'enabled': False,
                    'range_looks': 2,
                    'azimuth_looks': 2
                },
                
                'geometric_correction': {
                    'enabled': False,
                    'target_resolution': 10.0,  # meters
                    'resampling_method': 'bilinear'
                },
                
                'terrain_correction': {
                    'enabled': False,
                    'dem_path': None,
                    'dem_resampling': 'bilinear'
                }
            },
            
            'change_detection': {
                'method': 'log_ratio',  # log_ratio, ratio, difference, pca
                'threshold_method': 'otsu',  # otsu, mean, percentile, manual
                'threshold_value': None,  # For manual threshold
                'threshold_percentile': 95,  # For percentile threshold
                'post_processing': {
                    'enabled': True,
                    'min_area': 100,  # pixels
                    'morphological_operations': {
                        'enabled': True,
                        'operation': 'opening',  # opening, closing, erosion, dilation
                        'kernel_size': 3
                    }
                }
            },
            
            'output_settings': {
                'save_intermediate': True,
                'output_format': 'GeoTIFF',  # GeoTIFF, NetCDF
                'compression': 'lzw',
                'create_visualizations': True,
                'create_report': True,
                'coordinate_system': 'EPSG:4326'
            },
            
            'paths': {
                'data_dir': './data',
                'output_dir': './output',
                'temp_dir': './temp',
                'log_dir': './logs',
                'config_dir': './config'
            },
            
            'logging': {
                'level': 'INFO',  # DEBUG, INFO, WARNING, ERROR
                'log_to_file': True,
                'log_to_console': True,
                'max_log_size': '10 MB',
                'backup_count': 5
            },
            
            'performance': {
                'max_memory_usage': '4GB',
                'chunk_size': 1024,
                'parallel_processing': {
                    'enabled': True,
                    'max_workers': 4
                }
            }
        }
        
        return default_config
    
    def load_config(self, config_path: str) -> bool:
        """
        Load configuration from file.
        
        Args:
            config_path: Path to configuration file
            
        Returns:
            bool: True if successful
        """
        try:
            config_file = Path(config_path)
            
            if not config_file.exists():
                self.logger.error(f"Configuration file not found: {config_path}")
                return False
            
            # Load based on file extension
            if config_file.suffix.lower() in ['.yaml', '.yml']:
                with open(config_file, 'r') as f:
                    user_config = yaml.safe_load(f)
            elif config_file.suffix.lower() == '.json':
                with open(config_file, 'r') as f:
                    user_config = json.load(f)
            else:
                self.logger.error(f"Unsupported configuration file format: {config_file.suffix}")
                return False
            
            # Merge with default configuration
            self._merge_config(user_config)
            
            # Validate configuration
            if self.validate_config():
                self.config_path = config_path
                self.logger.info(f"Configuration loaded successfully: {config_path}")
                return True
            else:
                self.logger.error("Configuration validation failed")
                return False
                
        except Exception as e:
            self.logger.error(f"Failed to load configuration: {e}")
            return False
    
    def _merge_config(self, user_config: Dict[str, Any]) -> None:
        """
        Merge user configuration with default configuration.
        
        Args:
            user_config: User configuration dictionary
        """
        def merge_dict(default: Dict, user: Dict) -> Dict:
            """Recursively merge dictionaries."""
            for key, value in user.items():
                if key in default and isinstance(default[key], dict) and isinstance(value, dict):
                    merge_dict(default[key], value)
                else:
                    default[key] = value
            return default
        
        merge_dict(self.config, user_config)
    
    def validate_config(self) -> bool:
        """
        Validate configuration parameters.
        
        Returns:
            bool: True if valid
        """
        try:
            # Validate credentials
            if not self.config['credentials']['username']:
                self.logger.warning("Username not provided in configuration")
            
            if not self.config['credentials']['password']:
                self.logger.warning("Password not provided in configuration")
            
            # Validate search parameters
            valid_product_types = ['GRD', 'SLC']
            if self.config['search_parameters']['product_type'] not in valid_product_types:
                self.logger.error(f"Invalid product type: {self.config['search_parameters']['product_type']}")
                return False
            
            valid_sensor_modes = ['IW', 'EW', 'SM']
            if self.config['search_parameters']['sensor_mode'] not in valid_sensor_modes:
                self.logger.error(f"Invalid sensor mode: {self.config['search_parameters']['sensor_mode']}")
                return False
            
            valid_orbit_directions = ['ASCENDING', 'DESCENDING']
            if self.config['search_parameters']['orbit_direction'] not in valid_orbit_directions:
                self.logger.error(f"Invalid orbit direction: {self.config['search_parameters']['orbit_direction']}")
                return False
            
            # Validate processing parameters
            valid_calibration_types = ['sigma0', 'beta0', 'gamma0']
            calib_type = self.config['processing_parameters']['radiometric_calibration']['calibration_type']
            if calib_type not in valid_calibration_types:
                self.logger.error(f"Invalid calibration type: {calib_type}")
                return False
            
            valid_filter_types = ['lee', 'frost', 'kuan', 'gamma_map', 'adaptive']
            filter_type = self.config['processing_parameters']['speckle_filtering']['filter_type']
            if filter_type not in valid_filter_types:
                self.logger.error(f"Invalid filter type: {filter_type}")
                return False
            
            # Validate window size (must be odd)
            window_size = self.config['processing_parameters']['speckle_filtering']['window_size']
            if window_size % 2 == 0:
                self.logger.warning(f"Window size should be odd, adjusting from {window_size} to {window_size + 1}")
                self.config['processing_parameters']['speckle_filtering']['window_size'] = window_size + 1
            
            # Validate change detection parameters
            valid_cd_methods = ['log_ratio', 'ratio', 'difference', 'pca']
            cd_method = self.config['change_detection']['method']
            if cd_method not in valid_cd_methods:
                self.logger.error(f"Invalid change detection method: {cd_method}")
                return False
            
            valid_threshold_methods = ['otsu', 'mean', 'percentile', 'manual']
            threshold_method = self.config['change_detection']['threshold_method']
            if threshold_method not in valid_threshold_methods:
                self.logger.error(f"Invalid threshold method: {threshold_method}")
                return False
            
            # Validate paths
            for path_name, path_value in self.config['paths'].items():
                if not isinstance(path_value, str):
                    self.logger.error(f"Invalid path for {path_name}: {path_value}")
                    return False
            
            self.logger.info("Configuration validation passed")
            return True
            
        except Exception as e:
            self.logger.error(f"Configuration validation failed: {e}")
            return False
    
    def save_config(self, output_path: str, format: str = 'yaml') -> bool:
        """
        Save current configuration to file.
        
        Args:
            output_path: Output file path
            format: Output format ('yaml' or 'json')
            
        Returns:
            bool: True if successful
        """
        try:
            # Update metadata
            self.config['metadata']['modified'] = datetime.now().isoformat()
            
            output_file = Path(output_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            
            if format.lower() == 'yaml':
                with open(output_file, 'w') as f:
                    yaml.dump(self.config, f, default_flow_style=False, indent=2)
            elif format.lower() == 'json':
                with open(output_file, 'w') as f:
                    json.dump(self.config, f, indent=2, default=str)
            else:
                self.logger.error(f"Unsupported format: {format}")
                return False
            
            self.logger.info(f"Configuration saved: {output_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to save configuration: {e}")
            return False
    
    def get_parameter(self, parameter_path: str, default: Any = None) -> Any:
        """
        Get configuration parameter using dot notation.
        
        Args:
            parameter_path: Parameter path (e.g., 'processing_parameters.speckle_filtering.filter_type')
            default: Default value if parameter not found
            
        Returns:
            Parameter value or default
        """
        try:
            keys = parameter_path.split('.')
            value = self.config
            
            for key in keys:
                if isinstance(value, dict) and key in value:
                    value = value[key]
                else:
                    return default
            
            return value
            
        except Exception as e:
            self.logger.error(f"Failed to get parameter {parameter_path}: {e}")
            return default
    
    def set_parameter(self, parameter_path: str, value: Any) -> bool:
        """
        Set configuration parameter using dot notation.
        
        Args:
            parameter_path: Parameter path
            value: New value
            
        Returns:
            bool: True if successful
        """
        try:
            keys = parameter_path.split('.')
            config_ref = self.config
            
            # Navigate to parent dictionary
            for key in keys[:-1]:
                if key not in config_ref:
                    config_ref[key] = {}
                config_ref = config_ref[key]
            
            # Set value
            config_ref[keys[-1]] = value
            
            self.logger.info(f"Parameter set: {parameter_path} = {value}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to set parameter {parameter_path}: {e}")
            return False
    
    def create_template_config(self, output_path: str) -> bool:
        """
        Create a template configuration file with comments.
        
        Args:
            output_path: Output file path
            
        Returns:
            bool: True if successful
        """
        try:
            template_config = {
                'metadata': {
                    'version': '1.0.0',
                    'description': 'Sentinel-1 SAR Change Detection Configuration Template'
                },
                
                'credentials': {
                    'username': 'your_copernicus_username',
                    'password': 'your_copernicus_password',
                    'api_url': 'https://apihub.copernicus.eu/apihub'
                },
                
                'search_parameters': {
                    'product_type': 'GRD',
                    'sensor_mode': 'IW',
                    'polarization': 'VV VH',
                    'orbit_direction': 'DESCENDING',
                    'max_products': 5
                },
                
                'processing_parameters': {
                    'radiometric_calibration': {
                        'enabled': True,
                        'calibration_type': 'sigma0'
                    },
                    'speckle_filtering': {
                        'enabled': True,
                        'filter_type': 'lee',
                        'window_size': 5
                    }
                },
                
                'change_detection': {
                    'method': 'log_ratio',
                    'threshold_method': 'otsu',
                    'post_processing': {
                        'min_area': 100
                    }
                },
                
                'paths': {
                    'data_dir': './data',
                    'output_dir': './output',
                    'temp_dir': './temp'
                }
            }
            
            # Add comments as a separate file
            comments = """
# Sentinel-1 SAR Change Detection Configuration Template
# 
# This file contains the main configuration parameters for Sentinel-1 processing.
# Modify the values according to your requirements.
#
# Credentials:
#   - username: Your Copernicus Open Access Hub username
#   - password: Your Copernicus Open Access Hub password
#
# Search Parameters:
#   - product_type: GRD (Ground Range Detected) or SLC (Single Look Complex)
#   - sensor_mode: IW (Interferometric Wide), EW (Extra Wide), SM (Strip Map)
#   - polarization: VV, VH, HH, HV (space-separated for multiple)
#   - orbit_direction: ASCENDING or DESCENDING
#
# Processing Parameters:
#   - calibration_type: sigma0, beta0, or gamma0
#   - filter_type: lee, frost, kuan, gamma_map, or adaptive
#   - window_size: Filter window size (should be odd number)
#
# Change Detection:
#   - method: log_ratio, ratio, difference, or pca
#   - threshold_method: otsu, mean, percentile, or manual
#
# Paths:
#   - Use absolute paths or relative to working directory
            """
            
            output_file = Path(output_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            
            # Save template
            with open(output_file, 'w') as f:
                yaml.dump(template_config, f, default_flow_style=False, indent=2)
            
            # Save comments file
            comments_file = output_file.with_suffix('.comments.txt')
            with open(comments_file, 'w') as f:
                f.write(comments)
            
            self.logger.info(f"Template configuration created: {output_path}")
            self.logger.info(f"Comments file created: {comments_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to create template configuration: {e}")
            return False
    
    def get_config_summary(self) -> str:
        """
        Get a summary of current configuration.
        
        Returns:
            Configuration summary string
        """
        try:
            summary = "=== Sentinel-1 Configuration Summary ===\n\n"
            
            # Credentials
            summary += "Credentials:\n"
            summary += f"  Username: {'***' if self.config['credentials']['username'] else 'Not set'}\n"
            summary += f"  Password: {'***' if self.config['credentials']['password'] else 'Not set'}\n\n"
            
            # Search parameters
            summary += "Search Parameters:\n"
            search_params = self.config['search_parameters']
            summary += f"  Product Type: {search_params['product_type']}\n"
            summary += f"  Sensor Mode: {search_params['sensor_mode']}\n"
            summary += f"  Polarization: {search_params['polarization']}\n"
            summary += f"  Orbit Direction: {search_params['orbit_direction']}\n"
            summary += f"  Max Products: {search_params['max_products']}\n\n"
            
            # Processing parameters
            summary += "Processing Parameters:\n"
            proc_params = self.config['processing_parameters']
            summary += f"  Radiometric Calibration: {proc_params['radiometric_calibration']['enabled']}\n"
            summary += f"  Calibration Type: {proc_params['radiometric_calibration']['calibration_type']}\n"
            summary += f"  Speckle Filtering: {proc_params['speckle_filtering']['enabled']}\n"
            summary += f"  Filter Type: {proc_params['speckle_filtering']['filter_type']}\n"
            summary += f"  Window Size: {proc_params['speckle_filtering']['window_size']}\n\n"
            
            # Change detection
            summary += "Change Detection:\n"
            cd_params = self.config['change_detection']
            summary += f"  Method: {cd_params['method']}\n"
            summary += f"  Threshold Method: {cd_params['threshold_method']}\n"
            summary += f"  Min Area: {cd_params['post_processing']['min_area']} pixels\n\n"
            
            # Paths
            summary += "Paths:\n"
            for path_name, path_value in self.config['paths'].items():
                summary += f"  {path_name.replace('_', ' ').title()}: {path_value}\n"
            
            return summary
            
        except Exception as e:
            self.logger.error(f"Failed to generate configuration summary: {e}")
            return "Configuration summary not available"


# Example usage and testing
def test_config_manager():
    """Test configuration manager functionality."""
    print("Testing Configuration Manager...")
    
    # Initialize config manager
    config_manager = ConfigManager()
    
    # Test parameter access
    filter_type = config_manager.get_parameter('processing_parameters.speckle_filtering.filter_type')
    print(f"Filter type: {filter_type}")
    
    # Test parameter setting
    config_manager.set_parameter('processing_parameters.speckle_filtering.window_size', 7)
    window_size = config_manager.get_parameter('processing_parameters.speckle_filtering.window_size')
    print(f"Updated window size: {window_size}")
    
    # Test configuration summary
    summary = config_manager.get_config_summary()
    print("\nConfiguration Summary:")
    print(summary)
    
    print("Configuration manager tests completed.")


if __name__ == "__main__":
    test_config_manager()

