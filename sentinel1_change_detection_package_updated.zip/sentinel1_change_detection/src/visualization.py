#!/usr/bin/env python3
"""
Visualization Tools Module

This module provides comprehensive visualization tools for SAR data analysis,
change detection results, and statistical plots.

Author: Manus AI
Date: 2025
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.colors import ListedColormap, BoundaryNorm
import seaborn as sns
from typing import List, Tuple, Optional, Dict, Union
import warnings
warnings.filterwarnings('ignore')

# Geospatial
import rasterio
from rasterio.plot import show
import geopandas as gpd

# Image processing
from skimage import exposure

from loguru import logger


class VisualizationTools:
    """
    Comprehensive visualization tools for SAR data and change detection.
    """
    
    def __init__(self, style: str = 'seaborn-v0_8'):
        """
        Initialize visualization tools.
        
        Args:
            style: Matplotlib style
        """
        self.logger = logger
        
        # Set style
        try:
            plt.style.use(style)
        except:
            plt.style.use('default')
        
        # Set default parameters
        plt.rcParams['figure.figsize'] = (12, 8)
        plt.rcParams['font.size'] = 10
        plt.rcParams['axes.grid'] = True
        plt.rcParams['grid.alpha'] = 0.3
    
    def plot_sar_image(self, 
                      image_path: str,
                      title: str = "SAR Image",
                      band: int = 1,
                      percentile_stretch: Tuple[float, float] = (2, 98),
                      colormap: str = 'gray',
                      save_path: str = None,
                      figsize: Tuple[int, int] = (10, 8)) -> plt.Figure:
        """
        Plot SAR image with proper visualization.
        
        Args:
            image_path: Path to SAR image
            title: Plot title
            band: Band number to plot
            percentile_stretch: Percentile values for contrast stretching
            colormap: Colormap name
            save_path: Path to save plot
            figsize: Figure size
            
        Returns:
            Matplotlib figure
        """
        try:
            fig, ax = plt.subplots(1, 1, figsize=figsize)
            
            with rasterio.open(image_path) as src:
                # Read image data
                image = src.read(band)
                
                # Handle nodata values
                if src.nodata is not None:
                    image = np.ma.masked_equal(image, src.nodata)
                
                # Apply percentile stretch
                if percentile_stretch:
                    p_low, p_high = np.nanpercentile(image, percentile_stretch)
                    image = np.clip(image, p_low, p_high)
                    image = (image - p_low) / (p_high - p_low)
                
                # Plot image
                im = ax.imshow(image, cmap=colormap, aspect='equal')
                
                # Add colorbar
                cbar = plt.colorbar(im, ax=ax, shrink=0.8)
                cbar.set_label('Backscatter (dB)' if np.min(image) < 0 else 'Intensity')
                
                # Set title and labels
                ax.set_title(title, fontsize=14, fontweight='bold')
                ax.set_xlabel('Pixel X')
                ax.set_ylabel('Pixel Y')
                
                # Add image info
                info_text = f"Size: {src.width}×{src.height}\nCRS: {src.crs}"
                ax.text(0.02, 0.98, info_text, transform=ax.transAxes,
                       verticalalignment='top', bbox=dict(boxstyle='round', 
                       facecolor='white', alpha=0.8))
            
            plt.tight_layout()
            
            if save_path:
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
                self.logger.info(f"SAR image plot saved: {save_path}")
            
            return fig
            
        except Exception as e:
            self.logger.error(f"SAR image plotting failed: {e}")
            return None
    
    def plot_change_detection_results(self,
                                    change_map_path: str,
                                    title: str = "Change Detection Results",
                                    save_path: str = None,
                                    figsize: Tuple[int, int] = (15, 6)) -> plt.Figure:
        """
        Plot change detection results with multiple visualizations.
        
        Args:
            change_map_path: Path to change detection result
            title: Plot title
            save_path: Path to save plot
            figsize: Figure size
            
        Returns:
            Matplotlib figure
        """
        try:
            with rasterio.open(change_map_path) as src:
                change_map = src.read(1)
                binary_map = src.read(2) if src.count > 1 else None
            
            # Create subplots
            n_plots = 3 if binary_map is not None else 2
            fig, axes = plt.subplots(1, n_plots, figsize=figsize)
            
            if n_plots == 2:
                axes = [axes] if not isinstance(axes, np.ndarray) else axes
            
            # Plot 1: Continuous change map
            im1 = axes[0].imshow(change_map, cmap='RdBu_r', 
                               vmin=np.nanpercentile(change_map, 5),
                               vmax=np.nanpercentile(change_map, 95))
            axes[0].set_title('Continuous Change Map')
            axes[0].axis('off')
            cbar1 = plt.colorbar(im1, ax=axes[0], shrink=0.8)
            cbar1.set_label('Change Magnitude')
            
            # Plot 2: Change histogram
            axes[1].hist(change_map.flatten(), bins=50, alpha=0.7, 
                        color='blue', edgecolor='black')
            axes[1].set_xlabel('Change Value')
            axes[1].set_ylabel('Frequency')
            axes[1].set_title('Change Distribution')
            axes[1].grid(True, alpha=0.3)
            
            # Add statistics
            stats_text = f"Mean: {np.nanmean(change_map):.3f}\n"
            stats_text += f"Std: {np.nanstd(change_map):.3f}\n"
            stats_text += f"Min: {np.nanmin(change_map):.3f}\n"
            stats_text += f"Max: {np.nanmax(change_map):.3f}"
            
            axes[1].text(0.02, 0.98, stats_text, transform=axes[1].transAxes,
                        verticalalignment='top', bbox=dict(boxstyle='round',
                        facecolor='white', alpha=0.8))
            
            # Plot 3: Binary change map (if available)
            if binary_map is not None:
                # Create custom colormap for binary changes
                colors = ['lightblue', 'red']
                cmap = ListedColormap(colors)
                
                im3 = axes[2].imshow(binary_map, cmap=cmap, vmin=0, vmax=1)
                axes[2].set_title('Binary Change Map')
                axes[2].axis('off')
                
                # Add colorbar with labels
                cbar3 = plt.colorbar(im3, ax=axes[2], shrink=0.8, ticks=[0, 1])
                cbar3.set_ticklabels(['No Change', 'Change'])
                
                # Calculate change statistics
                total_pixels = binary_map.size
                changed_pixels = np.sum(binary_map)
                change_percentage = (changed_pixels / total_pixels) * 100
                
                change_stats = f"Changed: {changed_pixels:,} pixels\n"
                change_stats += f"Total: {total_pixels:,} pixels\n"
                change_stats += f"Change: {change_percentage:.2f}%"
                
                axes[2].text(0.02, 0.98, change_stats, transform=axes[2].transAxes,
                           verticalalignment='top', bbox=dict(boxstyle='round',
                           facecolor='white', alpha=0.8))
            
            plt.suptitle(title, fontsize=16, fontweight='bold')
            plt.tight_layout()
            
            if save_path:
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
                self.logger.info(f"Change detection plot saved: {save_path}")
            
            return fig
            
        except Exception as e:
            self.logger.error(f"Change detection plotting failed: {e}")
            return None
    
    def plot_before_after_comparison(self,
                                   image1_path: str,
                                   image2_path: str,
                                   change_map_path: str = None,
                                   titles: List[str] = None,
                                   save_path: str = None,
                                   figsize: Tuple[int, int] = (18, 6)) -> plt.Figure:
        """
        Plot before/after comparison with optional change map.
        
        Args:
            image1_path: Path to first (before) image
            image2_path: Path to second (after) image
            change_map_path: Path to change map (optional)
            titles: List of subplot titles
            save_path: Path to save plot
            figsize: Figure size
            
        Returns:
            Matplotlib figure
        """
        try:
            n_plots = 3 if change_map_path else 2
            fig, axes = plt.subplots(1, n_plots, figsize=figsize)
            
            if n_plots == 2:
                axes = [axes] if not isinstance(axes, np.ndarray) else axes
            
            # Default titles
            if titles is None:
                titles = ['Before', 'After', 'Change Map']
            
            # Plot before image
            with rasterio.open(image1_path) as src1:
                image1 = src1.read(1)
                if src1.nodata is not None:
                    image1 = np.ma.masked_equal(image1, src1.nodata)
                
                # Percentile stretch
                p2, p98 = np.nanpercentile(image1, [2, 98])
                image1_stretched = np.clip((image1 - p2) / (p98 - p2), 0, 1)
                
                im1 = axes[0].imshow(image1_stretched, cmap='gray')
                axes[0].set_title(titles[0], fontsize=14, fontweight='bold')
                axes[0].axis('off')
                
                # Add timestamp if available
                if hasattr(src1, 'tags') and 'TIFFTAG_DATETIME' in src1.tags():
                    timestamp = src1.tags()['TIFFTAG_DATETIME']
                    axes[0].text(0.02, 0.02, timestamp, transform=axes[0].transAxes,
                               bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
            
            # Plot after image
            with rasterio.open(image2_path) as src2:
                image2 = src2.read(1)
                if src2.nodata is not None:
                    image2 = np.ma.masked_equal(image2, src2.nodata)
                
                # Use same stretch as first image for comparison
                image2_stretched = np.clip((image2 - p2) / (p98 - p2), 0, 1)
                
                im2 = axes[1].imshow(image2_stretched, cmap='gray')
                axes[1].set_title(titles[1], fontsize=14, fontweight='bold')
                axes[1].axis('off')
                
                # Add timestamp if available
                if hasattr(src2, 'tags') and 'TIFFTAG_DATETIME' in src2.tags():
                    timestamp = src2.tags()['TIFFTAG_DATETIME']
                    axes[1].text(0.02, 0.02, timestamp, transform=axes[1].transAxes,
                               bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
            
            # Plot change map if provided
            if change_map_path and n_plots == 3:
                with rasterio.open(change_map_path) as src_change:
                    change_map = src_change.read(1)
                    
                    im3 = axes[2].imshow(change_map, cmap='RdBu_r',
                                       vmin=np.nanpercentile(change_map, 5),
                                       vmax=np.nanpercentile(change_map, 95))
                    axes[2].set_title(titles[2], fontsize=14, fontweight='bold')
                    axes[2].axis('off')
                    
                    # Add colorbar
                    cbar = plt.colorbar(im3, ax=axes[2], shrink=0.8)
                    cbar.set_label('Change Magnitude')
            
            plt.tight_layout()
            
            if save_path:
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
                self.logger.info(f"Before/after comparison saved: {save_path}")
            
            return fig
            
        except Exception as e:
            self.logger.error(f"Before/after comparison plotting failed: {e}")
            return None
    
    def plot_processing_workflow(self,
                               original_path: str,
                               calibrated_path: str,
                               filtered_path: str,
                               save_path: str = None,
                               figsize: Tuple[int, int] = (18, 6)) -> plt.Figure:
        """
        Plot SAR processing workflow steps.
        
        Args:
            original_path: Path to original image
            calibrated_path: Path to calibrated image
            filtered_path: Path to filtered image
            save_path: Path to save plot
            figsize: Figure size
            
        Returns:
            Matplotlib figure
        """
        try:
            fig, axes = plt.subplots(1, 3, figsize=figsize)
            
            titles = ['Original', 'Calibrated', 'Filtered']
            paths = [original_path, calibrated_path, filtered_path]
            
            for i, (path, title) in enumerate(zip(paths, titles)):
                if path and os.path.exists(path):
                    with rasterio.open(path) as src:
                        image = src.read(1)
                        
                        # Handle nodata
                        if src.nodata is not None:
                            image = np.ma.masked_equal(image, src.nodata)
                        
                        # Percentile stretch
                        p2, p98 = np.nanpercentile(image, [2, 98])
                        image_stretched = np.clip((image - p2) / (p98 - p2), 0, 1)
                        
                        im = axes[i].imshow(image_stretched, cmap='gray')
                        axes[i].set_title(title, fontsize=14, fontweight='bold')
                        axes[i].axis('off')
                        
                        # Add statistics
                        stats = f"Min: {np.nanmin(image):.2f}\n"
                        stats += f"Max: {np.nanmax(image):.2f}\n"
                        stats += f"Mean: {np.nanmean(image):.2f}\n"
                        stats += f"Std: {np.nanstd(image):.2f}"
                        
                        axes[i].text(0.02, 0.98, stats, transform=axes[i].transAxes,
                                   verticalalignment='top', 
                                   bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
                else:
                    axes[i].text(0.5, 0.5, 'Image not available', 
                               transform=axes[i].transAxes, ha='center', va='center')
                    axes[i].set_title(title, fontsize=14, fontweight='bold')
                    axes[i].axis('off')
            
            plt.suptitle('SAR Processing Workflow', fontsize=16, fontweight='bold')
            plt.tight_layout()
            
            if save_path:
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
                self.logger.info(f"Processing workflow plot saved: {save_path}")
            
            return fig
            
        except Exception as e:
            self.logger.error(f"Processing workflow plotting failed: {e}")
            return None
    
    def plot_statistics_comparison(self,
                                 stats_dict: Dict[str, Dict],
                                 save_path: str = None,
                                 figsize: Tuple[int, int] = (15, 10)) -> plt.Figure:
        """
        Plot statistical comparison between images.
        
        Args:
            stats_dict: Dictionary with image statistics
            save_path: Path to save plot
            figsize: Figure size
            
        Returns:
            Matplotlib figure
        """
        try:
            fig, axes = plt.subplots(2, 2, figsize=figsize)
            axes = axes.flatten()
            
            # Extract data for plotting
            image_names = list(stats_dict.keys())
            metrics = ['mean', 'std', 'min', 'max']
            
            for i, metric in enumerate(metrics):
                values = []
                for name in image_names:
                    if 'band_1' in stats_dict[name]:
                        values.append(stats_dict[name]['band_1'][metric])
                    else:
                        values.append(0)
                
                # Bar plot
                bars = axes[i].bar(image_names, values, alpha=0.7)
                axes[i].set_title(f'{metric.capitalize()} Values', fontweight='bold')
                axes[i].set_ylabel(metric.capitalize())
                axes[i].tick_params(axis='x', rotation=45)
                
                # Add value labels on bars
                for bar, value in zip(bars, values):
                    height = bar.get_height()
                    axes[i].text(bar.get_x() + bar.get_width()/2., height,
                               f'{value:.2f}', ha='center', va='bottom')
            
            plt.suptitle('Image Statistics Comparison', fontsize=16, fontweight='bold')
            plt.tight_layout()
            
            if save_path:
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
                self.logger.info(f"Statistics comparison plot saved: {save_path}")
            
            return fig
            
        except Exception as e:
            self.logger.error(f"Statistics comparison plotting failed: {e}")
            return None
    
    def plot_aoi_on_map(self,
                       aoi_geojson: Union[str, Dict],
                       background_image: str = None,
                       save_path: str = None,
                       figsize: Tuple[int, int] = (10, 8)) -> plt.Figure:
        """
        Plot area of interest on map.
        
        Args:
            aoi_geojson: AOI as GeoJSON file or dictionary
            background_image: Optional background image
            save_path: Path to save plot
            figsize: Figure size
            
        Returns:
            Matplotlib figure
        """
        try:
            fig, ax = plt.subplots(1, 1, figsize=figsize)
            
            # Load AOI
            if isinstance(aoi_geojson, str):
                aoi_gdf = gpd.read_file(aoi_geojson)
            else:
                aoi_gdf = gpd.GeoDataFrame.from_features(aoi_geojson['features'])
            
            # Plot background image if provided
            if background_image and os.path.exists(background_image):
                with rasterio.open(background_image) as src:
                    show(src, ax=ax, alpha=0.7)
            
            # Plot AOI
            aoi_gdf.plot(ax=ax, facecolor='none', edgecolor='red', 
                        linewidth=2, alpha=0.8)
            
            # Set title and labels
            ax.set_title('Area of Interest', fontsize=14, fontweight='bold')
            ax.set_xlabel('Longitude')
            ax.set_ylabel('Latitude')
            
            # Add grid
            ax.grid(True, alpha=0.3)
            
            # Add AOI info
            bounds = aoi_gdf.total_bounds
            area = aoi_gdf.geometry.area.sum()
            
            info_text = f"Bounds: {bounds[0]:.3f}, {bounds[1]:.3f}, {bounds[2]:.3f}, {bounds[3]:.3f}\n"
            info_text += f"Area: {area:.6f} deg²"
            
            ax.text(0.02, 0.98, info_text, transform=ax.transAxes,
                   verticalalignment='top', bbox=dict(boxstyle='round',
                   facecolor='white', alpha=0.8))
            
            plt.tight_layout()
            
            if save_path:
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
                self.logger.info(f"AOI map saved: {save_path}")
            
            return fig
            
        except Exception as e:
            self.logger.error(f"AOI mapping failed: {e}")
            return None
    
    def create_processing_report(self,
                               results: Dict,
                               output_dir: str) -> str:
        """
        Create comprehensive processing report with visualizations.
        
        Args:
            results: Processing results dictionary
            output_dir: Output directory for report
            
        Returns:
            Path to generated report
        """
        try:
            import os
            from datetime import datetime
            
            # Create report directory
            report_dir = os.path.join(output_dir, 'processing_report')
            os.makedirs(report_dir, exist_ok=True)
            
            # Generate plots
            plots_created = []
            
            # Plot change detection results if available
            if 'change_maps' in results and results['change_maps']:
                for i, change_map in enumerate(results['change_maps']):
                    if os.path.exists(change_map):
                        plot_path = os.path.join(report_dir, f'change_detection_{i}.png')
                        fig = self.plot_change_detection_results(change_map, save_path=plot_path)
                        if fig:
                            plots_created.append(plot_path)
                            plt.close(fig)
            
            # Create HTML report
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Sentinel-1 Change Detection Report</title>
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 40px; }}
                    h1 {{ color: #2c3e50; }}
                    h2 {{ color: #34495e; }}
                    .summary {{ background-color: #ecf0f1; padding: 20px; border-radius: 5px; }}
                    .plot {{ text-align: center; margin: 20px 0; }}
                    img {{ max-width: 100%; height: auto; }}
                    table {{ border-collapse: collapse; width: 100%; }}
                    th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                    th {{ background-color: #f2f2f2; }}
                </style>
            </head>
            <body>
                <h1>Sentinel-1 SAR Change Detection Report</h1>
                <p>Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
                
                <div class="summary">
                    <h2>Processing Summary</h2>
                    <table>
                        <tr><th>Parameter</th><th>Value</th></tr>
                        <tr><td>Success</td><td>{'Yes' if results.get('success', False) else 'No'}</td></tr>
                        <tr><td>Products Found</td><td>{results.get('products_found', 0)}</td></tr>
                        <tr><td>Products Downloaded</td><td>{results.get('products_downloaded', 0)}</td></tr>
                        <tr><td>Change Maps Created</td><td>{len(results.get('change_maps', []))}</td></tr>
                    </table>
                </div>
                
                <h2>Change Detection Results</h2>
            """
            
            # Add plots to HTML
            for i, plot_path in enumerate(plots_created):
                plot_name = os.path.basename(plot_path)
                html_content += f"""
                <div class="plot">
                    <h3>Change Detection Result {i+1}</h3>
                    <img src="{plot_name}" alt="Change Detection {i+1}">
                </div>
                """
            
            html_content += """
            </body>
            </html>
            """
            
            # Save HTML report
            report_path = os.path.join(report_dir, 'processing_report.html')
            with open(report_path, 'w') as f:
                f.write(html_content)
            
            self.logger.info(f"Processing report created: {report_path}")
            return report_path
            
        except Exception as e:
            self.logger.error(f"Report creation failed: {e}")
            return None


# Example usage and testing
def test_visualization_tools():
    """Test visualization tools."""
    print("Testing Visualization Tools...")
    
    # Create synthetic data for testing
    np.random.seed(42)
    
    # Create synthetic SAR images
    image1 = np.random.gamma(2, 2, (100, 100))
    image2 = image1 + np.random.normal(0, 0.5, (100, 100))
    change_map = image2 - image1
    
    # Initialize visualization tools
    viz = VisualizationTools()
    
    # Test statistics comparison
    stats_dict = {
        'Image 1': {'band_1': {'mean': np.mean(image1), 'std': np.std(image1),
                               'min': np.min(image1), 'max': np.max(image1)}},
        'Image 2': {'band_1': {'mean': np.mean(image2), 'std': np.std(image2),
                               'min': np.min(image2), 'max': np.max(image2)}}
    }
    
    fig = viz.plot_statistics_comparison(stats_dict)
    if fig:
        plt.show()
        plt.close(fig)
    
    print("Visualization tools tests completed.")


if __name__ == "__main__":
    test_visualization_tools()

