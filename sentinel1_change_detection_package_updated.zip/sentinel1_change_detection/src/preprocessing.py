#!/usr/bin/env python3
"""
SAR Preprocessing Module

This module provides specialized functions for SAR image preprocessing including
radiometric calibration, speckle filtering, geometric correction, and terrain correction.

Author: Manus AI
Date: 2025
"""

import numpy as np
from typing import Tuple, Optional, Union
import warnings
warnings.filterwarnings('ignore')

# Image processing
import cv2
from scipy import ndimage, signal
from skimage import filters, morphology, restoration

# Geospatial
import rasterio
from rasterio.transform import from_bounds
from rasterio.warp import reproject, Resampling

from loguru import logger


class SARPreprocessor:
    """
    SAR preprocessing utilities for Sentinel-1 data.
    """
    
    def __init__(self):
        """Initialize SAR preprocessor."""
        self.logger = logger
    
    def radiometric_calibration(self, 
                               input_data: np.ndarray,
                               calibration_type: str = 'sigma0',
                               noise_equivalent_sigma0: float = -22.0) -> np.ndarray:
        """
        Perform radiometric calibration on SAR data.
        
        Args:
            input_data: Input SAR data (DN values)
            calibration_type: Type of calibration ('sigma0', 'beta0', 'gamma0')
            noise_equivalent_sigma0: Noise equivalent sigma0 in dB
            
        Returns:
            Calibrated SAR data
        """
        try:
            # Convert to float32 to avoid overflow
            data = input_data.astype(np.float32)
            
            if calibration_type == 'sigma0':
                # Convert DN to sigma0 (simplified calibration)
                # In practice, use proper calibration LUT from metadata
                calibrated = 10 * np.log10(np.maximum(data**2, 1e-10))
                
                # Apply noise correction
                calibrated = np.maximum(calibrated, noise_equivalent_sigma0)
                
            elif calibration_type == 'beta0':
                # Beta nought calibration
                calibrated = 10 * np.log10(np.maximum(data**2, 1e-10))
                
            elif calibration_type == 'gamma0':
                # Gamma nought calibration (terrain corrected)
                calibrated = 10 * np.log10(np.maximum(data**2, 1e-10))
                
            else:
                self.logger.warning(f"Unknown calibration type: {calibration_type}")
                calibrated = data
            
            self.logger.info(f"Radiometric calibration ({calibration_type}) completed")
            return calibrated
            
        except Exception as e:
            self.logger.error(f"Radiometric calibration failed: {e}")
            return input_data
    
    def lee_filter(self, 
                   image: np.ndarray, 
                   window_size: int = 5,
                   cu: float = 0.25) -> np.ndarray:
        """
        Apply Lee speckle filter.
        
        Args:
            image: Input SAR image
            window_size: Filter window size (odd number)
            cu: Noise coefficient
            
        Returns:
            Filtered image
        """
        try:
            # Ensure odd window size
            if window_size % 2 == 0:
                window_size += 1
            
            # Convert to linear scale if in dB
            if np.min(image) < 0:
                linear_image = 10**(image / 10)
            else:
                linear_image = image
            
            # Pad image
            pad_size = window_size // 2
            padded = np.pad(linear_image, pad_size, mode='reflect')
            
            # Initialize output
            filtered = np.zeros_like(linear_image)
            
            # Apply Lee filter
            for i in range(linear_image.shape[0]):
                for j in range(linear_image.shape[1]):
                    # Extract window
                    window = padded[i:i+window_size, j:j+window_size]
                    
                    # Calculate statistics
                    mean_val = np.mean(window)
                    var_val = np.var(window)
                    
                    # Lee filter formula
                    if var_val > 0:
                        ci = np.sqrt(var_val) / mean_val
                        if ci > cu:
                            k = (1 - cu**2 / ci**2) / (1 + cu**2)
                            filtered[i, j] = mean_val + k * (linear_image[i, j] - mean_val)
                        else:
                            filtered[i, j] = mean_val
                    else:
                        filtered[i, j] = linear_image[i, j]
            
            # Convert back to dB if input was in dB
            if np.min(image) < 0:
                filtered = 10 * np.log10(np.maximum(filtered, 1e-10))
            
            self.logger.info("Lee filter applied successfully")
            return filtered
            
        except Exception as e:
            self.logger.error(f"Lee filter failed: {e}")
            return image
    
    def frost_filter(self, 
                     image: np.ndarray, 
                     window_size: int = 5,
                     damping_factor: float = 1.0) -> np.ndarray:
        """
        Apply Frost speckle filter.
        
        Args:
            image: Input SAR image
            window_size: Filter window size
            damping_factor: Damping factor
            
        Returns:
            Filtered image
        """
        try:
            # Ensure odd window size
            if window_size % 2 == 0:
                window_size += 1
            
            # Convert to linear scale if in dB
            if np.min(image) < 0:
                linear_image = 10**(image / 10)
            else:
                linear_image = image
            
            # Pad image
            pad_size = window_size // 2
            padded = np.pad(linear_image, pad_size, mode='reflect')
            
            # Initialize output
            filtered = np.zeros_like(linear_image)
            
            # Create distance matrix
            center = window_size // 2
            y, x = np.ogrid[-center:center+1, -center:center+1]
            distance = np.sqrt(x*x + y*y)
            
            # Apply Frost filter
            for i in range(linear_image.shape[0]):
                for j in range(linear_image.shape[1]):
                    # Extract window
                    window = padded[i:i+window_size, j:j+window_size]
                    
                    # Calculate statistics
                    mean_val = np.mean(window)
                    var_val = np.var(window)
                    
                    if var_val > 0:
                        # Frost filter weights
                        ci = np.sqrt(var_val) / mean_val
                        weights = np.exp(-damping_factor * ci * distance)
                        weights /= np.sum(weights)
                        
                        # Apply weighted average
                        filtered[i, j] = np.sum(weights * window)
                    else:
                        filtered[i, j] = mean_val
            
            # Convert back to dB if input was in dB
            if np.min(image) < 0:
                filtered = 10 * np.log10(np.maximum(filtered, 1e-10))
            
            self.logger.info("Frost filter applied successfully")
            return filtered
            
        except Exception as e:
            self.logger.error(f"Frost filter failed: {e}")
            return image
    
    def kuan_filter(self, 
                    image: np.ndarray, 
                    window_size: int = 5,
                    cu: float = 0.25) -> np.ndarray:
        """
        Apply Kuan speckle filter.
        
        Args:
            image: Input SAR image
            window_size: Filter window size
            cu: Noise coefficient
            
        Returns:
            Filtered image
        """
        try:
            # Ensure odd window size
            if window_size % 2 == 0:
                window_size += 1
            
            # Convert to linear scale if in dB
            if np.min(image) < 0:
                linear_image = 10**(image / 10)
            else:
                linear_image = image
            
            # Apply uniform filter for local mean
            kernel = np.ones((window_size, window_size)) / (window_size * window_size)
            local_mean = ndimage.convolve(linear_image, kernel, mode='reflect')
            
            # Calculate local variance
            local_mean_sq = ndimage.convolve(linear_image**2, kernel, mode='reflect')
            local_var = local_mean_sq - local_mean**2
            
            # Kuan filter
            ci = np.sqrt(local_var) / np.maximum(local_mean, 1e-10)
            w = (1 - cu**2 / np.maximum(ci**2, cu**2)) / (1 + cu**2)
            w = np.clip(w, 0, 1)
            
            filtered = local_mean + w * (linear_image - local_mean)
            
            # Convert back to dB if input was in dB
            if np.min(image) < 0:
                filtered = 10 * np.log10(np.maximum(filtered, 1e-10))
            
            self.logger.info("Kuan filter applied successfully")
            return filtered
            
        except Exception as e:
            self.logger.error(f"Kuan filter failed: {e}")
            return image
    
    def gamma_map_filter(self, 
                        image: np.ndarray, 
                        window_size: int = 5,
                        looks: int = 1) -> np.ndarray:
        """
        Apply Gamma MAP speckle filter.
        
        Args:
            image: Input SAR image
            window_size: Filter window size
            looks: Number of looks
            
        Returns:
            Filtered image
        """
        try:
            # Ensure odd window size
            if window_size % 2 == 0:
                window_size += 1
            
            # Convert to linear scale if in dB
            if np.min(image) < 0:
                linear_image = 10**(image / 10)
            else:
                linear_image = image
            
            # Apply uniform filter for local statistics
            kernel = np.ones((window_size, window_size)) / (window_size * window_size)
            local_mean = ndimage.convolve(linear_image, kernel, mode='reflect')
            local_mean_sq = ndimage.convolve(linear_image**2, kernel, mode='reflect')
            local_var = local_mean_sq - local_mean**2
            
            # Gamma MAP filter
            cu = 1.0 / np.sqrt(looks)  # Theoretical coefficient of variation
            ci = np.sqrt(local_var) / np.maximum(local_mean, 1e-10)
            
            # Weight calculation
            w = np.where(ci > cu, 
                        (ci**2 - cu**2) / (ci**2 * (1 + cu**2)),
                        0)
            w = np.clip(w, 0, 1)
            
            filtered = local_mean + w * (linear_image - local_mean)
            
            # Convert back to dB if input was in dB
            if np.min(image) < 0:
                filtered = 10 * np.log10(np.maximum(filtered, 1e-10))
            
            self.logger.info("Gamma MAP filter applied successfully")
            return filtered
            
        except Exception as e:
            self.logger.error(f"Gamma MAP filter failed: {e}")
            return image
    
    def adaptive_filter(self, 
                       image: np.ndarray, 
                       window_size: int = 5) -> np.ndarray:
        """
        Apply adaptive speckle filter that automatically selects the best method.
        
        Args:
            image: Input SAR image
            window_size: Filter window size
            
        Returns:
            Filtered image
        """
        try:
            # Calculate image statistics to determine best filter
            if np.min(image) < 0:
                linear_image = 10**(image / 10)
            else:
                linear_image = image
            
            # Calculate coefficient of variation
            mean_val = np.mean(linear_image)
            std_val = np.std(linear_image)
            cv = std_val / mean_val if mean_val > 0 else 0
            
            # Select filter based on image characteristics
            if cv < 0.5:
                # Low speckle - use Lee filter
                filtered = self.lee_filter(image, window_size)
                filter_used = "Lee"
            elif cv < 1.0:
                # Medium speckle - use Kuan filter
                filtered = self.kuan_filter(image, window_size)
                filter_used = "Kuan"
            else:
                # High speckle - use Gamma MAP filter
                filtered = self.gamma_map_filter(image, window_size)
                filter_used = "Gamma MAP"
            
            self.logger.info(f"Adaptive filter applied: {filter_used} (CV: {cv:.3f})")
            return filtered
            
        except Exception as e:
            self.logger.error(f"Adaptive filter failed: {e}")
            return image
    
    def multilook_processing(self, 
                           image: np.ndarray, 
                           range_looks: int = 2,
                           azimuth_looks: int = 2) -> np.ndarray:
        """
        Apply multilook processing to reduce speckle.
        
        Args:
            image: Input SAR image
            range_looks: Number of looks in range direction
            azimuth_looks: Number of looks in azimuth direction
            
        Returns:
            Multilooked image
        """
        try:
            # Convert to linear scale if in dB
            if np.min(image) < 0:
                linear_image = 10**(image / 10)
            else:
                linear_image = image
            
            # Calculate new dimensions
            new_height = linear_image.shape[0] // azimuth_looks
            new_width = linear_image.shape[1] // range_looks
            
            # Reshape and average
            reshaped = linear_image[:new_height*azimuth_looks, :new_width*range_looks]
            reshaped = reshaped.reshape(new_height, azimuth_looks, new_width, range_looks)
            multilooked = np.mean(reshaped, axis=(1, 3))
            
            # Convert back to dB if input was in dB
            if np.min(image) < 0:
                multilooked = 10 * np.log10(np.maximum(multilooked, 1e-10))
            
            self.logger.info(f"Multilook processing applied: {range_looks}x{azimuth_looks}")
            return multilooked
            
        except Exception as e:
            self.logger.error(f"Multilook processing failed: {e}")
            return image
    
    def geometric_correction(self, 
                           image: np.ndarray,
                           input_transform: rasterio.transform.Affine,
                           target_resolution: float = 10.0) -> Tuple[np.ndarray, rasterio.transform.Affine]:
        """
        Apply geometric correction to SAR image.
        
        Args:
            image: Input SAR image
            input_transform: Input image transform
            target_resolution: Target pixel resolution in meters
            
        Returns:
            Tuple of (corrected_image, new_transform)
        """
        try:
            # Calculate new transform for target resolution
            new_transform = rasterio.transform.Affine(
                target_resolution, 0.0, input_transform.c,
                0.0, -target_resolution, input_transform.f
            )
            
            # Calculate new dimensions
            scale_x = abs(input_transform.a) / target_resolution
            scale_y = abs(input_transform.e) / target_resolution
            
            new_width = int(image.shape[1] * scale_x)
            new_height = int(image.shape[0] * scale_y)
            
            # Resample image
            corrected = cv2.resize(image, (new_width, new_height), 
                                 interpolation=cv2.INTER_LINEAR)
            
            self.logger.info(f"Geometric correction applied: {target_resolution}m resolution")
            return corrected, new_transform
            
        except Exception as e:
            self.logger.error(f"Geometric correction failed: {e}")
            return image, input_transform
    
    def terrain_correction(self, 
                          image: np.ndarray,
                          dem_path: str = None) -> np.ndarray:
        """
        Apply terrain correction using DEM (simplified implementation).
        
        Args:
            image: Input SAR image
            dem_path: Path to DEM file (optional)
            
        Returns:
            Terrain corrected image
        """
        try:
            # Simplified terrain correction
            # In practice, this would use proper DEM and geometric models
            
            if dem_path and os.path.exists(dem_path):
                # Load DEM and apply proper terrain correction
                with rasterio.open(dem_path) as dem_src:
                    dem = dem_src.read(1)
                    # Apply terrain correction based on DEM
                    # This is a placeholder for complex terrain correction
                    corrected = image  # Simplified
            else:
                # Apply simple radiometric terrain correction
                # Assume flat terrain and apply basic correction
                corrected = image
            
            self.logger.info("Terrain correction applied")
            return corrected
            
        except Exception as e:
            self.logger.error(f"Terrain correction failed: {e}")
            return image
    
    def process_sar_image(self, 
                         input_path: str,
                         output_path: str,
                         calibration_type: str = 'sigma0',
                         speckle_filter: str = 'lee',
                         window_size: int = 5,
                         multilook: bool = False,
                         target_resolution: float = None) -> bool:
        """
        Complete SAR preprocessing pipeline.
        
        Args:
            input_path: Input SAR image path
            output_path: Output processed image path
            calibration_type: Radiometric calibration type
            speckle_filter: Speckle filter type
            window_size: Filter window size
            multilook: Apply multilook processing
            target_resolution: Target resolution for geometric correction
            
        Returns:
            bool: True if successful
        """
        try:
            with rasterio.open(input_path) as src:
                # Read image
                image = src.read(1).astype(np.float32)
                profile = src.profile.copy()
                
                # Step 1: Radiometric calibration
                image = self.radiometric_calibration(image, calibration_type)
                
                # Step 2: Speckle filtering
                if speckle_filter == 'lee':
                    image = self.lee_filter(image, window_size)
                elif speckle_filter == 'frost':
                    image = self.frost_filter(image, window_size)
                elif speckle_filter == 'kuan':
                    image = self.kuan_filter(image, window_size)
                elif speckle_filter == 'gamma_map':
                    image = self.gamma_map_filter(image, window_size)
                elif speckle_filter == 'adaptive':
                    image = self.adaptive_filter(image, window_size)
                
                # Step 3: Multilook processing (optional)
                if multilook:
                    image = self.multilook_processing(image)
                    # Update profile for new dimensions
                    profile.update(height=image.shape[0], width=image.shape[1])
                
                # Step 4: Geometric correction (optional)
                if target_resolution:
                    image, new_transform = self.geometric_correction(
                        image, src.transform, target_resolution
                    )
                    profile.update(
                        height=image.shape[0], 
                        width=image.shape[1],
                        transform=new_transform
                    )
                
                # Update profile
                profile.update(dtype=rasterio.float32, nodata=-9999)
                
                # Save processed image
                with rasterio.open(output_path, 'w', **profile) as dst:
                    dst.write(image, 1)
                
                self.logger.info(f"SAR preprocessing completed: {output_path}")
                return True
                
        except Exception as e:
            self.logger.error(f"SAR preprocessing failed: {e}")
            return False


# Example usage and testing
def test_sar_preprocessing():
    """Test SAR preprocessing functions."""
    print("Testing SAR Preprocessing...")
    
    # Create synthetic SAR data
    np.random.seed(42)
    synthetic_sar = np.random.gamma(2, 2, (100, 100)).astype(np.float32)
    
    # Add speckle noise
    speckle = np.random.gamma(1, 1, (100, 100))
    noisy_sar = synthetic_sar * speckle
    
    # Initialize preprocessor
    preprocessor = SARPreprocessor()
    
    # Test different filters
    lee_filtered = preprocessor.lee_filter(noisy_sar)
    frost_filtered = preprocessor.frost_filter(noisy_sar)
    kuan_filtered = preprocessor.kuan_filter(noisy_sar)
    
    print(f"Original image shape: {noisy_sar.shape}")
    print(f"Lee filtered shape: {lee_filtered.shape}")
    print(f"Frost filtered shape: {frost_filtered.shape}")
    print(f"Kuan filtered shape: {kuan_filtered.shape}")
    
    # Test multilook
    multilooked = preprocessor.multilook_processing(noisy_sar, 2, 2)
    print(f"Multilooked shape: {multilooked.shape}")
    
    print("SAR preprocessing tests completed.")


if __name__ == "__main__":
    test_sar_preprocessing()

