#!/usr/bin/env python3
"""
Data Utilities Module

This module provides utility functions for data handling, file operations,
coordinate transformations, and data validation for Sentinel-1 processing.

Author: Manus AI
Date: 2025
"""

import os
import json
import zipfile
import shutil
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Union
import warnings
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
from loguru import logger

# Geospatial libraries
import rasterio
from rasterio.transform import from_bounds
from rasterio.crs import CRS
from rasterio.warp import calculate_default_transform, reproject, Resampling
import geopandas as gpd
from shapely.geometry import Polygon, box, Point
import pyproj

# Sentinel data
from sentinelsat import read_geojson, geojson_to_wkt


class DataUtils:
    """
    Utility class for data handling operations.
    """
    
    @staticmethod
    def validate_geojson(geojson_data: Union[str, Dict]) -> bool:
        """
        Validate GeoJSON data format.
        
        Args:
            geojson_data: GeoJSON file path or dictionary
            
        Returns:
            bool: True if valid, False otherwise
        """
        try:
            if isinstance(geojson_data, str):
                with open(geojson_data, 'r') as f:
                    data = json.load(f)
            else:
                data = geojson_data
            
            # Basic validation
            if 'type' not in data:
                return False
            
            if data['type'] == 'FeatureCollection':
                return 'features' in data and len(data['features']) > 0
            elif data['type'] == 'Feature':
                return 'geometry' in data
            elif data['type'] in ['Polygon', 'MultiPolygon', 'Point', 'LineString']:
                return 'coordinates' in data
            
            return False
            
        except Exception as e:
            logger.error(f"GeoJSON validation failed: {e}")
            return False
    
    @staticmethod
    def create_aoi_from_bounds(bounds: Tuple[float, float, float, float], 
                              crs: str = 'EPSG:4326') -> Dict:
        """
        Create AOI GeoJSON from bounding box.
        
        Args:
            bounds: (min_x, min_y, max_x, max_y)
            crs: Coordinate reference system
            
        Returns:
            GeoJSON dictionary
        """
        min_x, min_y, max_x, max_y = bounds
        
        polygon = Polygon([
            (min_x, min_y),
            (max_x, min_y),
            (max_x, max_y),
            (min_x, max_y),
            (min_x, min_y)
        ])
        
        geojson = {
            "type": "FeatureCollection",
            "crs": {"type": "name", "properties": {"name": crs}},
            "features": [
                {
                    "type": "Feature",
                    "properties": {},
                    "geometry": {
                        "type": "Polygon",
                        "coordinates": [list(polygon.exterior.coords)]
                    }
                }
            ]
        }
        
        return geojson
    
    @staticmethod
    def create_aoi_from_point(lat: float, lon: float, 
                             buffer_km: float = 10) -> Dict:
        """
        Create AOI GeoJSON from center point and buffer.
        
        Args:
            lat: Latitude
            lon: Longitude
            buffer_km: Buffer distance in kilometers
            
        Returns:
            GeoJSON dictionary
        """
        # Create point and buffer
        point = Point(lon, lat)
        
        # Convert to UTM for accurate buffering
        utm_crs = DataUtils.get_utm_crs(lat, lon)
        
        # Transform to UTM
        transformer = pyproj.Transformer.from_crs('EPSG:4326', utm_crs, always_xy=True)
        utm_x, utm_y = transformer.transform(lon, lat)
        utm_point = Point(utm_x, utm_y)
        
        # Buffer in meters
        buffered = utm_point.buffer(buffer_km * 1000)
        
        # Transform back to WGS84
        transformer_back = pyproj.Transformer.from_crs(utm_crs, 'EPSG:4326', always_xy=True)
        
        # Get exterior coordinates and transform
        coords = []
        for x, y in buffered.exterior.coords:
            lon_new, lat_new = transformer_back.transform(x, y)
            coords.append([lon_new, lat_new])
        
        geojson = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "properties": {},
                    "geometry": {
                        "type": "Polygon",
                        "coordinates": [coords]
                    }
                }
            ]
        }
        
        return geojson
    
    @staticmethod
    def get_utm_crs(lat: float, lon: float) -> str:
        """
        Get UTM CRS for given coordinates.
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            UTM CRS string
        """
        utm_zone = int((lon + 180) / 6) + 1
        hemisphere = 'north' if lat >= 0 else 'south'
        
        if hemisphere == 'north':
            epsg_code = 32600 + utm_zone
        else:
            epsg_code = 32700 + utm_zone
        
        return f'EPSG:{epsg_code}'
    
    @staticmethod
    def reproject_raster(input_path: str, output_path: str, 
                        target_crs: str, resolution: float = None) -> bool:
        """
        Reproject raster to target CRS.
        
        Args:
            input_path: Input raster path
            output_path: Output raster path
            target_crs: Target coordinate reference system
            resolution: Target resolution (optional)
            
        Returns:
            bool: True if successful
        """
        try:
            with rasterio.open(input_path) as src:
                # Calculate transform and dimensions
                transform, width, height = calculate_default_transform(
                    src.crs, target_crs, src.width, src.height, *src.bounds,
                    resolution=resolution
                )
                
                # Update profile
                profile = src.profile.copy()
                profile.update({
                    'crs': target_crs,
                    'transform': transform,
                    'width': width,
                    'height': height
                })
                
                # Reproject
                with rasterio.open(output_path, 'w', **profile) as dst:
                    for i in range(1, src.count + 1):
                        reproject(
                            source=rasterio.band(src, i),
                            destination=rasterio.band(dst, i),
                            src_transform=src.transform,
                            src_crs=src.crs,
                            dst_transform=transform,
                            dst_crs=target_crs,
                            resampling=Resampling.bilinear
                        )
                
                logger.info(f"Reprojected raster saved: {output_path}")
                return True
                
        except Exception as e:
            logger.error(f"Raster reprojection failed: {e}")
            return False
    
    @staticmethod
    def clip_raster_to_aoi(input_path: str, output_path: str, 
                          aoi_geojson: Union[str, Dict]) -> bool:
        """
        Clip raster to area of interest.
        
        Args:
            input_path: Input raster path
            output_path: Output clipped raster path
            aoi_geojson: AOI as GeoJSON file or dictionary
            
        Returns:
            bool: True if successful
        """
        try:
            # Load AOI
            if isinstance(aoi_geojson, str):
                aoi_gdf = gpd.read_file(aoi_geojson)
            else:
                aoi_gdf = gpd.GeoDataFrame.from_features(aoi_geojson['features'])
            
            # Clip raster
            with rasterio.open(input_path) as src:
                # Reproject AOI to raster CRS if needed
                if aoi_gdf.crs != src.crs:
                    aoi_gdf = aoi_gdf.to_crs(src.crs)
                
                # Get geometry for clipping
                geometries = aoi_gdf.geometry.values
                
                # Clip
                from rasterio.mask import mask
                clipped_data, clipped_transform = mask(src, geometries, crop=True)
                
                # Update profile
                profile = src.profile.copy()
                profile.update({
                    'height': clipped_data.shape[1],
                    'width': clipped_data.shape[2],
                    'transform': clipped_transform
                })
                
                # Save clipped raster
                with rasterio.open(output_path, 'w', **profile) as dst:
                    dst.write(clipped_data)
                
                logger.info(f"Clipped raster saved: {output_path}")
                return True
                
        except Exception as e:
            logger.error(f"Raster clipping failed: {e}")
            return False
    
    @staticmethod
    def extract_sentinel1_metadata(zip_path: str) -> Dict:
        """
        Extract metadata from Sentinel-1 ZIP file.
        
        Args:
            zip_path: Path to Sentinel-1 ZIP file
            
        Returns:
            Dictionary with metadata
        """
        metadata = {}
        
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                # Find manifest file
                manifest_files = [f for f in zip_ref.namelist() 
                                if f.endswith('manifest.safe')]
                
                if manifest_files:
                    manifest_content = zip_ref.read(manifest_files[0]).decode('utf-8')
                    
                    # Parse basic metadata (simplified)
                    import xml.etree.ElementTree as ET
                    root = ET.fromstring(manifest_content)
                    
                    # Extract key information
                    for elem in root.iter():
                        if 'missionDataTakeId' in elem.tag:
                            metadata['mission_datatake_id'] = elem.text
                        elif 'productType' in elem.tag:
                            metadata['product_type'] = elem.text
                        elif 'polarisation' in elem.tag:
                            metadata['polarisation'] = elem.text
                        elif 'orbitDirection' in elem.tag:
                            metadata['orbit_direction'] = elem.text
                
                # Get file list
                tiff_files = [f for f in zip_ref.namelist() 
                             if f.endswith('.tiff') and 'measurement' in f.lower()]
                metadata['measurement_files'] = tiff_files
                
        except Exception as e:
            logger.error(f"Metadata extraction failed: {e}")
        
        return metadata
    
    @staticmethod
    def calculate_image_statistics(image_path: str) -> Dict:
        """
        Calculate basic statistics for raster image.
        
        Args:
            image_path: Path to raster image
            
        Returns:
            Dictionary with statistics
        """
        stats = {}
        
        try:
            with rasterio.open(image_path) as src:
                for band_idx in range(1, src.count + 1):
                    band_data = src.read(band_idx)
                    
                    # Remove nodata values
                    if src.nodata is not None:
                        band_data = band_data[band_data != src.nodata]
                    
                    band_stats = {
                        'min': float(np.nanmin(band_data)),
                        'max': float(np.nanmax(band_data)),
                        'mean': float(np.nanmean(band_data)),
                        'std': float(np.nanstd(band_data)),
                        'percentile_2': float(np.nanpercentile(band_data, 2)),
                        'percentile_98': float(np.nanpercentile(band_data, 98))
                    }
                    
                    stats[f'band_{band_idx}'] = band_stats
                
                # Image properties
                stats['image_info'] = {
                    'width': src.width,
                    'height': src.height,
                    'count': src.count,
                    'crs': str(src.crs),
                    'bounds': src.bounds,
                    'resolution': src.res
                }
                
        except Exception as e:
            logger.error(f"Statistics calculation failed: {e}")
        
        return stats
    
    @staticmethod
    def clean_temp_files(temp_dir: str, keep_patterns: List[str] = None) -> None:
        """
        Clean temporary files.
        
        Args:
            temp_dir: Temporary directory path
            keep_patterns: List of file patterns to keep
        """
        try:
            temp_path = Path(temp_dir)
            if not temp_path.exists():
                return
            
            keep_patterns = keep_patterns or []
            
            for file_path in temp_path.rglob('*'):
                if file_path.is_file():
                    # Check if file should be kept
                    keep_file = False
                    for pattern in keep_patterns:
                        if pattern in file_path.name:
                            keep_file = True
                            break
                    
                    if not keep_file:
                        try:
                            file_path.unlink()
                        except Exception as e:
                            logger.warning(f"Could not delete {file_path}: {e}")
            
            logger.info(f"Cleaned temporary files in {temp_dir}")
            
        except Exception as e:
            logger.error(f"Temp file cleanup failed: {e}")
    
    @staticmethod
    def create_directory_structure(base_dir: str) -> Dict[str, str]:
        """
        Create standard directory structure for processing.
        
        Args:
            base_dir: Base directory path
            
        Returns:
            Dictionary with directory paths
        """
        base_path = Path(base_dir)
        
        directories = {
            'data': base_path / 'data',
            'output': base_path / 'output',
            'temp': base_path / 'temp',
            'logs': base_path / 'logs',
            'config': base_path / 'config',
            'results': base_path / 'results',
            'visualizations': base_path / 'visualizations'
        }
        
        # Create directories
        for name, path in directories.items():
            path.mkdir(parents=True, exist_ok=True)
            logger.info(f"Created directory: {path}")
        
        return {name: str(path) for name, path in directories.items()}
    
    @staticmethod
    def validate_date_range(date_range: Tuple[str, str]) -> bool:
        """
        Validate date range format.
        
        Args:
            date_range: Tuple of (start_date, end_date)
            
        Returns:
            bool: True if valid
        """
        try:
            from datetime import datetime
            
            start_date, end_date = date_range
            
            # Parse dates
            start_dt = datetime.strptime(start_date, '%Y-%m-%d')
            end_dt = datetime.strptime(end_date, '%Y-%m-%d')
            
            # Check if end date is after start date
            if end_dt <= start_dt:
                logger.error("End date must be after start date")
                return False
            
            # Check if dates are not in the future
            now = datetime.now()
            if start_dt > now or end_dt > now:
                logger.warning("Date range includes future dates")
            
            return True
            
        except ValueError as e:
            logger.error(f"Invalid date format: {e}")
            return False
    
    @staticmethod
    def save_processing_report(results: Dict, output_path: str) -> None:
        """
        Save processing report as JSON.
        
        Args:
            results: Processing results dictionary
            output_path: Output file path
        """
        try:
            # Add timestamp
            from datetime import datetime
            results['timestamp'] = datetime.now().isoformat()
            results['version'] = "1.0.0"
            
            with open(output_path, 'w') as f:
                json.dump(results, f, indent=2, default=str)
            
            logger.info(f"Processing report saved: {output_path}")
            
        except Exception as e:
            logger.error(f"Failed to save processing report: {e}")


# Example usage and testing functions
def test_data_utils():
    """Test data utilities functions."""
    print("Testing Data Utilities...")
    
    # Test AOI creation from bounds
    bounds = (11.0, 46.0, 11.5, 46.5)
    aoi = DataUtils.create_aoi_from_bounds(bounds)
    print(f"AOI from bounds: {aoi['type']}")
    
    # Test AOI creation from point
    aoi_point = DataUtils.create_aoi_from_point(46.25, 11.25, buffer_km=5)
    print(f"AOI from point: {aoi_point['type']}")
    
    # Test date validation
    valid_dates = ('2023-01-01', '2023-12-31')
    is_valid = DataUtils.validate_date_range(valid_dates)
    print(f"Date range valid: {is_valid}")
    
    print("Data utilities tests completed.")


if __name__ == "__main__":
    test_data_utils()

