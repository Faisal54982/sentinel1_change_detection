"""
Sentinel-1 SAR Change Detection Package

A comprehensive Python package for downloading, preprocessing, and performing 
change detection on Sentinel-1 SAR images.

Modules:
    - sentinel1_change_detection: Main processing class
    - data_utils: Data handling utilities
    - preprocessing: SAR preprocessing functions
    - visualization: Plotting and visualization tools
    - config_manager: Configuration management
"""

__version__ = "1.0.0"
__author__ = "Manus AI"
__email__ = "support@manus.ai"

from .sentinel1_change_detection import Sentinel1ChangeDetection
from .data_utils import DataUtils
from .preprocessing import SARPreprocessor
from .visualization import VisualizationTools
from .config_manager import ConfigManager

__all__ = [
    'Sentinel1ChangeDetection',
    'DataUtils', 
    'SARPreprocessor',
    'VisualizationTools',
    'ConfigManager'
]

