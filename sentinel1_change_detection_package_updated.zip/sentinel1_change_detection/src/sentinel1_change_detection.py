#!/usr/bin/env python3
"""
Sentinel-1 SAR Change Detection Script

This script demonstrates how to download, preprocess, and perform change detection 
on Sentinel-1 images using Python. The script performs the following steps:

1. Define user credentials for Copernicus Open Access Hub
2. Define area of interest (AOI) and date range
3. Connect to Copernicus Open Access Hub API
4. Search and download Sentinel-1 images
5. Extract and preprocess SAR images
6. Perform change detection analysis
7. Save results as GeoTIFF files

Author: Manus AI
Date: 2025
"""

import os
import sys
import json
import zipfile
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Union
import warnings
warnings.filterwarnings('ignore')

# Core libraries
import numpy as np
import pandas as pd
from loguru import logger

# Geospatial libraries
import rasterio
from rasterio.transform import from_bounds
from rasterio.crs import CRS
from rasterio.warp import calculate_default_transform, reproject, Resampling
import geopandas as gpd
from shapely.geometry import Polygon, box
import pyproj

# Sentinel data access
from sentinelsat import SentinelAPI, read_geojson, geojson_to_wkt

# Image processing
import cv2
from skimage import filters, morphology, exposure
from scipy import ndimage
import matplotlib.pyplot as plt

# Progress tracking
from tqdm import tqdm

# Configuration
import yaml


class Sentinel1ChangeDetection:
    """
    Main class for Sentinel-1 SAR change detection workflow.
    """
    
    def __init__(self, config_path: str = None):
        """
        Initialize the Sentinel-1 change detection processor.
        
        Args:
            config_path: Path to configuration file
        """
        self.config = self._load_config(config_path)
        self.api = None
        
        # Create output directories
        self.data_dir = Path(self.config['paths']['data_dir'])
        self.output_dir = Path(self.config['paths']['output_dir'])
        self.temp_dir = Path(self.config['paths']['temp_dir'])
        
        for directory in [self.data_dir, self.output_dir, self.temp_dir]:
            directory.mkdir(parents=True, exist_ok=True)
        
        self.logger = self._setup_logging()
    
    def _load_config(self, config_path: str) -> Dict:
        """Load configuration from file or use defaults."""
        default_config = {
            'credentials': {
                'username': 'your_username',
                'password': 'your_password'
            },
            'search_params': {
                'product_type': 'GRD',
                'sensor_mode': 'IW',
                'polarization': 'VV VH',
                'orbit_direction': 'DESCENDING'
            },
            'processing': {
                'target_resolution': 10,
                'speckle_filter': 'lee',
                'calibration': 'sigma0',
                'multilook': True
            },
            'change_detection': {
                'method': 'log_ratio',
                'threshold': 'otsu',
                'min_area': 100
            },
            'paths': {
                'data_dir': './data',
                'output_dir': './output',
                'temp_dir': './temp'
            }
        }
        
        if config_path and os.path.exists(config_path):
            with open(config_path, 'r') as f:
                user_config = yaml.safe_load(f)
            # Merge with defaults
            for key, value in user_config.items():
                if isinstance(value, dict) and key in default_config:
                    if isinstance(default_config[key], dict):
                        default_config[key].update(value)
                    else:
                        default_config[key] = value
                else:
                    default_config[key] = value
        
        return default_config
    
    def _setup_logging(self) -> logger:
        """Setup logging configuration."""
        logger.remove()
        logger.add(
            sys.stdout,
            format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
            level="INFO"
        )
        logger.add(
            self.output_dir / "sentinel1_processing.log",
            format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}",
            level="DEBUG",
            rotation="10 MB"
        )
        return logger
    
    def connect_to_api(self) -> bool:
        """
        Connect to Copernicus Open Access Hub API.
        
        Returns:
            bool: True if connection successful, False otherwise
        """
        try:
            username = self.config['credentials']['username']
            password = self.config['credentials']['password']
            
            if not username or not password:
                self.logger.error("Username and password are required")
                return False
            
            # Connect to Copernicus Data Space Ecosystem
            # Note: CDSE uses OAuth2 authentication and different endpoints
            self.api = SentinelAPI(
                username,
                password,
                'https://catalogue.dataspace.copernicus.eu/odata/v1'
            )
            self.logger.info("Successfully connected to Copernicus Data Space Ecosystem")
            return True
        except Exception as e:
            self.logger.error(f"Failed to connect to API: {e}")
            return False
    
    def search_products(self, 
                       aoi_geojson: Union[str, Dict], 
                       date_range: Tuple[str, str],
                       **kwargs) -> pd.DataFrame:
        """
        Search for Sentinel-1 products.
        
        Args:
            aoi_geojson: Area of interest as GeoJSON file path or dictionary
            date_range: Tuple of (start_date, end_date) in 'YYYY-MM-DD' format
            **kwargs: Additional search parameters
            
        Returns:
            DataFrame with search results
        """
        if not self.api:
            raise RuntimeError("API connection not established. Call connect_to_api() first.")
        
        # Process AOI
        if isinstance(aoi_geojson, str):
            footprint = geojson_to_wkt(read_geojson(aoi_geojson))
        else:
            footprint = geojson_to_wkt(aoi_geojson)
        
        # Prepare search parameters
        search_params = {
            'footprint': footprint,
            'date': date_range,
            'platformname': 'Sentinel-1',
            'producttype': self.config['search_params']['product_type'],
            'sensoroperationalmode': self.config['search_params']['sensor_mode'],
            'orbitdirection': self.config['search_params']['orbit_direction']
        }
        
        # Add any additional parameters
        search_params.update(kwargs)
        
        self.logger.info(f"Searching for products with parameters: {search_params}")
        
        try:
            products = self.api.query(**search_params)
            products_df = self.api.to_dataframe(products)
            
            self.logger.info(f"Found {len(products_df)} products")
            return products_df
            
        except Exception as e:
            self.logger.error(f"Search failed: {e}")
            return pd.DataFrame()
    
    def download_products(self, products_df: pd.DataFrame, max_products: int = None) -> List[str]:
        """
        Download Sentinel-1 products.
        
        Args:
            products_df: DataFrame with product information
            max_products: Maximum number of products to download
            
        Returns:
            List of downloaded file paths
        """
        if products_df.empty:
            self.logger.warning("No products to download")
            return []
        
        # Sort by sensing date and limit if specified
        products_df = products_df.sort_values('beginposition')
        if max_products:
            products_df = products_df.head(max_products)
        
        downloaded_files = []
        
        for idx, (product_id, product_info) in enumerate(tqdm(products_df.iterrows(), 
                                                              desc="Downloading products",
                                                              total=len(products_df))):
            try:
                self.logger.info(f"Downloading product {idx+1}/{len(products_df)}: {product_info['title']}")
                
                # Check if already downloaded
                expected_path = self.data_dir / f"{product_info['title']}.zip"
                if expected_path.exists():
                    self.logger.info(f"Product already exists: {expected_path}")
                    downloaded_files.append(str(expected_path))
                    continue
                
                # Download product
                product_info_dict = self.api.download(product_id, directory_path=str(self.data_dir))
                downloaded_files.append(product_info_dict['path'])
                
            except Exception as e:
                self.logger.error(f"Failed to download {product_info['title']}: {e}")
                continue
        
        self.logger.info(f"Successfully downloaded {len(downloaded_files)} products")
        return downloaded_files
    
    def extract_geotiff_from_zip(self, zip_path: str) -> List[str]:
        """
        Extract GeoTIFF files from Sentinel-1 ZIP archive.
        
        Args:
            zip_path: Path to ZIP file
            
        Returns:
            List of extracted GeoTIFF file paths
        """
        extracted_files = []
        extract_dir = self.temp_dir / Path(zip_path).stem
        extract_dir.mkdir(exist_ok=True)
        
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                # Find measurement files (GeoTIFF)
                tiff_files = [f for f in zip_ref.namelist() 
                             if f.endswith('.tiff') and 'measurement' in f.lower()]
                
                for tiff_file in tiff_files:
                    zip_ref.extract(tiff_file, extract_dir)
                    extracted_path = extract_dir / tiff_file
                    extracted_files.append(str(extracted_path))
                    
                self.logger.info(f"Extracted {len(extracted_files)} GeoTIFF files from {zip_path}")
                
        except Exception as e:
            self.logger.error(f"Failed to extract files from {zip_path}: {e}")
        
        return extracted_files
    
    def radiometric_calibration(self, input_path: str, output_path: str, 
                               calibration_type: str = 'sigma0') -> bool:
        """
        Perform radiometric calibration on SAR image.
        
        Args:
            input_path: Input image path
            output_path: Output calibrated image path
            calibration_type: Type of calibration ('sigma0', 'beta0', 'gamma0')
            
        Returns:
            bool: True if successful
        """
        try:
            with rasterio.open(input_path) as src:
                # Read image data
                image = src.read(1).astype(np.float32)
                
                # Convert DN to backscatter coefficient
                if calibration_type == 'sigma0':
                    # Simplified calibration - in practice, use proper calibration LUT
                    calibrated = 10 * np.log10(np.maximum(image**2, 1e-10))
                else:
                    calibrated = image
                
                # Write calibrated image
                profile = src.profile.copy()
                profile.update(dtype=rasterio.float32, nodata=-9999)
                
                with rasterio.open(output_path, 'w', **profile) as dst:
                    dst.write(calibrated, 1)
                
                self.logger.info(f"Radiometric calibration completed: {output_path}")
                return True
                
        except Exception as e:
            self.logger.error(f"Radiometric calibration failed: {e}")
            return False
    
    def speckle_filtering(self, input_path: str, output_path: str, 
                         filter_type: str = 'lee', window_size: int = 5) -> bool:
        """
        Apply speckle filtering to SAR image.
        
        Args:
            input_path: Input image path
            output_path: Output filtered image path
            filter_type: Type of filter ('lee', 'frost', 'kuan', 'median')
            window_size: Filter window size
            
        Returns:
            bool: True if successful
        """
        try:
            with rasterio.open(input_path) as src:
                image = src.read(1).astype(np.float32)
                
                if filter_type == 'lee':
                    filtered = self._lee_filter(image, window_size)
                elif filter_type == 'median':
                    filtered = ndimage.median_filter(image, size=window_size)
                elif filter_type == 'gaussian':
                    filtered = ndimage.gaussian_filter(image, sigma=window_size/3)
                else:
                    # Default to median filter
                    filtered = ndimage.median_filter(image, size=window_size)
                
                # Write filtered image
                profile = src.profile.copy()
                profile.update(dtype=rasterio.float32)
                
                with rasterio.open(output_path, 'w', **profile) as dst:
                    dst.write(filtered, 1)
                
                self.logger.info(f"Speckle filtering completed: {output_path}")
                return True
                
        except Exception as e:
            self.logger.error(f"Speckle filtering failed: {e}")
            return False
    
    def _lee_filter(self, image: np.ndarray, window_size: int) -> np.ndarray:
        """
        Apply Lee speckle filter.
        
        Args:
            image: Input image array
            window_size: Filter window size
            
        Returns:
            Filtered image array
        """
        # Simplified Lee filter implementation
        kernel = np.ones((window_size, window_size)) / (window_size * window_size)
        
        # Calculate local mean and variance
        mean = ndimage.convolve(image, kernel, mode='reflect')
        sqr_mean = ndimage.convolve(image**2, kernel, mode='reflect')
        variance = sqr_mean - mean**2
        
        # Lee filter formula
        k = variance / (variance + mean**2 / 4)  # Simplified noise variance
        filtered = mean + k * (image - mean)
        
        return filtered
    
    def normalize_image(self, image: np.ndarray, method: str = 'minmax') -> np.ndarray:
        """
        Normalize image values.
        
        Args:
            image: Input image array
            method: Normalization method ('minmax', 'zscore', 'percentile')
            
        Returns:
            Normalized image array
        """
        if method == 'minmax':
            return (image - np.nanmin(image)) / (np.nanmax(image) - np.nanmin(image))
        elif method == 'zscore':
            return (image - np.nanmean(image)) / np.nanstd(image)
        elif method == 'percentile':
            p2, p98 = np.nanpercentile(image, [2, 98])
            return np.clip((image - p2) / (p98 - p2), 0, 1)
        else:
            return image
    
    def change_detection(self, image1_path: str, image2_path: str, 
                        output_path: str, method: str = 'log_ratio') -> bool:
        """
        Perform change detection between two SAR images.
        
        Args:
            image1_path: Path to first (reference) image
            image2_path: Path to second (target) image
            output_path: Path to save change detection result
            method: Change detection method ('log_ratio', 'ratio', 'difference')
            
        Returns:
            bool: True if successful
        """
        try:
            # Read images
            with rasterio.open(image1_path) as src1:
                image1 = src1.read(1).astype(np.float32)
                profile = src1.profile.copy()
            
            with rasterio.open(image2_path) as src2:
                image2 = src2.read(1).astype(np.float32)
            
            # Ensure images have same dimensions
            if image1.shape != image2.shape:
                self.logger.warning("Images have different dimensions. Resizing...")
                image2 = cv2.resize(image2, (image1.shape[1], image1.shape[0]))
            
            # Perform change detection
            if method == 'log_ratio':
                # Log ratio method (good for SAR)
                change_map = np.log(np.maximum(image2, 1e-10)) - np.log(np.maximum(image1, 1e-10))
            elif method == 'ratio':
                # Simple ratio
                change_map = image2 / np.maximum(image1, 1e-10)
            elif method == 'difference':
                # Absolute difference
                change_map = np.abs(image2 - image1)
            else:
                raise ValueError(f"Unknown change detection method: {method}")
            
            # Apply threshold to create binary change map
            threshold = self._calculate_threshold(change_map, self.config['change_detection']['threshold'])
            binary_change = np.abs(change_map) > threshold
            
            # Post-processing: remove small areas
            min_area = self.config['change_detection']['min_area']
            if min_area > 0:
                binary_change = morphology.remove_small_objects(
                    binary_change, min_size=min_area
                )
            
            # Save results
            profile.update(dtype=rasterio.float32, count=2)
            
            with rasterio.open(output_path, 'w', **profile) as dst:
                dst.write(change_map, 1)  # Continuous change map
                dst.write(binary_change.astype(np.float32), 2)  # Binary change map
            
            self.logger.info(f"Change detection completed: {output_path}")
            
            # Generate statistics
            change_pixels = np.sum(binary_change)
            total_pixels = binary_change.size
            change_percentage = (change_pixels / total_pixels) * 100
            
            self.logger.info(f"Change statistics:")
            self.logger.info(f"  - Changed pixels: {change_pixels}")
            self.logger.info(f"  - Total pixels: {total_pixels}")
            self.logger.info(f"  - Change percentage: {change_percentage:.2f}%")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Change detection failed: {e}")
            return False
    
    def _calculate_threshold(self, change_map: np.ndarray, method: str) -> float:
        """
        Calculate threshold for change detection.
        
        Args:
            change_map: Change detection map
            method: Threshold method ('otsu', 'mean', 'percentile', or numeric value)
            
        Returns:
            Threshold value
        """
        if method == 'otsu':
            # Use Otsu's method
            hist, bins = np.histogram(np.abs(change_map).flatten(), bins=256)
            threshold = filters.threshold_otsu(np.abs(change_map))
        elif method == 'mean':
            threshold = np.nanmean(np.abs(change_map))
        elif method == 'percentile':
            threshold = np.nanpercentile(np.abs(change_map), 95)
        else:
            try:
                threshold = float(method)
            except ValueError:
                self.logger.warning(f"Unknown threshold method: {method}. Using mean.")
                threshold = np.nanmean(np.abs(change_map))
        
        return threshold
    
    def create_visualization(self, change_map_path: str, output_path: str) -> bool:
        """
        Create visualization of change detection results.
        
        Args:
            change_map_path: Path to change detection result
            output_path: Path to save visualization
            
        Returns:
            bool: True if successful
        """
        try:
            with rasterio.open(change_map_path) as src:
                change_map = src.read(1)
                binary_map = src.read(2) if src.count > 1 else None
            
            fig, axes = plt.subplots(1, 2 if binary_map is not None else 1, 
                                   figsize=(15, 6))
            
            if binary_map is not None:
                # Continuous change map
                im1 = axes[0].imshow(change_map, cmap='RdBu_r', vmin=-2, vmax=2)
                axes[0].set_title('Continuous Change Map')
                axes[0].axis('off')
                plt.colorbar(im1, ax=axes[0], shrink=0.8)
                
                # Binary change map
                im2 = axes[1].imshow(binary_map, cmap='Reds', vmin=0, vmax=1)
                axes[1].set_title('Binary Change Map')
                axes[1].axis('off')
                plt.colorbar(im2, ax=axes[1], shrink=0.8)
            else:
                im = axes.imshow(change_map, cmap='RdBu_r')
                axes.set_title('Change Map')
                axes.axis('off')
                plt.colorbar(im, ax=axes, shrink=0.8)
            
            plt.tight_layout()
            plt.savefig(output_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            self.logger.info(f"Visualization saved: {output_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Visualization creation failed: {e}")
            return False
    
    def process_workflow(self, aoi_geojson: Union[str, Dict], 
                        date_range: Tuple[str, str],
                        max_products: int = 2) -> Dict:
        """
        Execute complete change detection workflow.
        
        Args:
            aoi_geojson: Area of interest
            date_range: Date range for image search
            max_products: Maximum number of products to process
            
        Returns:
            Dictionary with processing results
        """
        results = {
            'success': False,
            'products_found': 0,
            'products_downloaded': 0,
            'change_maps': [],
            'error': None
        }
        
        try:
            # Step 1: Connect to API
            if not self.connect_to_api():
                results['error'] = "Failed to connect to API"
                return results
            
            # Step 2: Search for products
            products_df = self.search_products(aoi_geojson, date_range)
            results['products_found'] = len(products_df)
            
            if products_df.empty:
                results['error'] = "No products found"
                return results
            
            # Step 3: Download products
            downloaded_files = self.download_products(products_df, max_products)
            results['products_downloaded'] = len(downloaded_files)
            
            if len(downloaded_files) < 2:
                results['error'] = "Need at least 2 images for change detection"
                return results
            
            # Step 4: Process images
            processed_images = []
            
            for zip_path in downloaded_files:
                # Extract GeoTIFF files
                tiff_files = self.extract_geotiff_from_zip(zip_path)
                
                for tiff_file in tiff_files:
                    # Radiometric calibration
                    calibrated_path = str(self.temp_dir / f"calibrated_{Path(tiff_file).name}")
                    if self.radiometric_calibration(tiff_file, calibrated_path):
                        
                        # Speckle filtering
                        filtered_path = str(self.temp_dir / f"filtered_{Path(tiff_file).name}")
                        if self.speckle_filtering(calibrated_path, filtered_path):
                            processed_images.append(filtered_path)
            
            # Step 5: Change detection
            if len(processed_images) >= 2:
                for i in range(len(processed_images) - 1):
                    change_map_path = str(self.output_dir / f"change_map_{i}_{i+1}.tif")
                    
                    if self.change_detection(processed_images[i], processed_images[i+1], 
                                           change_map_path):
                        results['change_maps'].append(change_map_path)
                        
                        # Create visualization
                        viz_path = str(self.output_dir / f"change_visualization_{i}_{i+1}.png")
                        self.create_visualization(change_map_path, viz_path)
            
            results['success'] = True
            self.logger.info("Workflow completed successfully")
            
        except Exception as e:
            results['error'] = str(e)
            self.logger.error(f"Workflow failed: {e}")
        
        return results


def main():
    """
    Main function to demonstrate the change detection workflow.
    """
    # Example configuration
    config = {
        'credentials': {
            'username': 'your_copernicus_username',
            'password': 'your_copernicus_password'
        },
        'search_params': {
            'product_type': 'GRD',
            'sensor_mode': 'IW',
            'polarization': 'VV VH',
            'orbit_direction': 'DESCENDING'
        },
        'processing': {
            'target_resolution': 10,
            'speckle_filter': 'lee',
            'calibration': 'sigma0'
        },
        'change_detection': {
            'method': 'log_ratio',
            'threshold': 'otsu',
            'min_area': 100
        },
        'paths': {
            'data_dir': './data',
            'output_dir': './output',
            'temp_dir': './temp'
        }
    }
    
    # Example AOI (small area for testing)
    aoi_geojson = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "properties": {},
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [[
                        [11.0, 46.0],
                        [11.5, 46.0],
                        [11.5, 46.5],
                        [11.0, 46.5],
                        [11.0, 46.0]
                    ]]
                }
            }
        ]
    }
    
    # Date range (adjust as needed)
    date_range = ('2023-01-01', '2023-12-31')
    
    # Initialize processor
    processor = Sentinel1ChangeDetection()
    
    # Run workflow
    results = processor.process_workflow(aoi_geojson, date_range, max_products=2)
    
    # Print results
    print("\n" + "="*50)
    print("SENTINEL-1 CHANGE DETECTION RESULTS")
    print("="*50)
    print(f"Success: {results['success']}")
    print(f"Products found: {results['products_found']}")
    print(f"Products downloaded: {results['products_downloaded']}")
    print(f"Change maps created: {len(results['change_maps'])}")
    
    if results['change_maps']:
        print("\nGenerated files:")
        for change_map in results['change_maps']:
            print(f"  - {change_map}")
    
    if results['error']:
        print(f"\nError: {results['error']}")


if __name__ == "__main__":
    main()

